#!/usr/bin/env python3
"""Make a public, relative-path SHA-256 artifact index without private keys."""
import argparse
import hashlib
import json
import os
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--dir',type=Path,required=True)
args=p.parse_args();root=args.dir.resolve()
items=[]
for f in sorted(root.rglob('*')):
    if not f.is_file() or f.name in ('SHA256SUMS.txt','evidence-manifest.json'):
        continue
    data=f.read_bytes()
    items.append({'path':str(f.relative_to(root)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with (root/'SHA256SUMS.txt').open('w') as fd:
    for x in items:fd.write(f"{x['sha256']}  {x['path']}\n")
(root/'evidence-manifest.json').write_text(json.dumps({
    'schema':'sha256-local-files-v1',
    'count':len(items),'files':items,
    'ci':{'repository':os.getenv('GITHUB_REPOSITORY'),'run_id':os.getenv('GITHUB_RUN_ID'),
          'commit':os.getenv('GITHUB_SHA'),'workflow_url':
          'https://github.com/'+os.getenv('GITHUB_REPOSITORY','')+'/actions/runs/'+os.getenv('GITHUB_RUN_ID','')
          if os.getenv('GITHUB_REPOSITORY') and os.getenv('GITHUB_RUN_ID') else None},
    'warning':'Hashes detect changes to this archived snapshot, not trusted signer custody or guaranteed honest experiment execution.'
},indent=2)+'\n')
print(f'INDEXED {len(items)} files at {root}')
