#!/usr/bin/env python3
"""Query-time, pre-mutation, authenticated selection-semantics capture.

Research prototype. Imports SHA-256-pinned upstream LangChain retriever source,
adds ONE call to an audit hook immediately after its stable sort and before the
upstream last_accessed_at mutation, and otherwise executes upstream methods.

Trust model: source/instrumentation and signing key are trusted. A signature on a
receipt cannot by itself prove candidate completeness, score correctness, or
historical reference authenticity. The verifier requires independent exact,
complete candidate scores for the target historical cut. This is neither a
production atomic log nor an installed-core test when shims are active.
"""
from __future__ import annotations

import base64
import copy
import datetime as dt
import hashlib
import importlib.util
import json
import math
import sys
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

UPSTREAM_COMMIT = 'bdf1cd383ce36dc18381a3bf3fb0a579337a32b5'
UPSTREAM_SHA256 = '2a55ff628c1d44ebf1faa01008579ac26ed0ae5996daec6dcde3ae4cb9233daa'
SRC = Path(__file__).resolve().parent / 'src' / 'time_weighted_retriever.py'
TARGET_LINE = '        rescored_docs.sort(key=lambda x: x[1], reverse=True)\n        result = []'
SELECTOR = 'time-weighted/stable-score-sort/source-pinned'


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def b64(b: bytes) -> str:
    return base64.b64encode(b).decode('ascii')


def iso(value: dt.datetime) -> str:
    return value.isoformat(timespec='microseconds')


def score_commitment(scores: dict[str, float]) -> str:
    """Exact IEEE-754 float hex, canonicalized by unique item ID."""
    assert len(scores) > 0 and all(math.isfinite(x) for x in scores.values())
    return digest([[ident, scores[ident].hex()] for ident in sorted(scores)])


class Signer:
    def __init__(self, key: Ed25519PrivateKey | None = None):
        self.private = key or Ed25519PrivateKey.generate()
        self.public = self.private.public_key()

    def sign(self, payload: dict) -> dict:
        return {'payload': copy.deepcopy(payload), 'sig_ed25519_b64': b64(self.private.sign(canonical(payload)))}

    def public_b64(self) -> str:
        return b64(self.public.public_bytes(Encoding.Raw, PublicFormat.Raw))


class InvalidEvidence(ValueError):
    pass


def verify_signature(envelope: Any, public_b64: str) -> dict:
    if not isinstance(envelope, dict) or set(envelope) != {'payload', 'sig_ed25519_b64'}:
        raise InvalidEvidence('invalid envelope shape')
    try:
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_b64, validate=True))
        signature = base64.b64decode(envelope['sig_ed25519_b64'], validate=True)
        public.verify(signature, canonical(envelope['payload']))
        if not isinstance(envelope['payload'], dict):
            raise InvalidEvidence('invalid payload')
        return envelope['payload']
    except Exception as exc:
        if isinstance(exc, InvalidEvidence):
            raise
        raise InvalidEvidence('signature invalid') from exc


def crossing_frontier(scores: dict[str, float], k: int) -> set[str]:
    if not 1 <= k <= len(scores):
        raise InvalidEvidence('k outside candidate universe')
    threshold = sorted(scores.values(), reverse=True)[k - 1]
    above = sum(s > threshold for s in scores.values())
    tied = {ident for ident, s in scores.items() if s == threshold}
    return tied if 0 < (k - above) < len(tied) else set()


def expected_topk(scores: dict[str, float], k: int, frontier_order: list[str] | None) -> set[str]:
    boundary = crossing_frontier(scores, k)
    threshold = sorted(scores.values(), reverse=True)[k - 1]
    strictly_higher = {i for i, s in scores.items() if s > threshold}
    if not boundary:
        return {i for i, s in scores.items() if s >= threshold}
    if not isinstance(frontier_order, list) or len(frontier_order) != len(boundary) or set(frontier_order) != boundary:
        raise InvalidEvidence('incomplete/invalid boundary order')
    return strictly_higher | set(frontier_order[:k - len(strictly_higher)])


def bytes_json(obj: Any) -> int:
    return len(canonical(obj))


@dataclass
class CapturedRead:
    prepare: dict
    commit: dict
    whole_trace_baseline: dict
    direct_reference_baseline: dict
    trusted_scores_ephemeral: dict[str, float]
    upstream_returned: list[str]
    candidate_iteration_ephemeral: list[str]


class CaptureSession:
    """Single read session; prepare durable logging should happen before mutation.

    `mode` controls only what the trusted signer retains for semantics replay;
    scores and candidate order are used transiently but NOT stored in selective
    receipt. Caller supplies a `write_prepare` function (potential fsync sink).
    """
    def __init__(self, signer: Signer, target: dict, write_prepare=None):
        self.signer = signer
        self.target = copy.deepcopy(target)
        self.write_prepare = write_prepare
        self.payloads = None
        self.preimages = None
        self.scores = None
        self.enumeration = None

    def pre_mutation_hook(self, retriever, before_sort, sorted_scored, timestamp):
        if self.payloads is not None:
            raise RuntimeError('multiple selection hooks in one read')
        input_docs = list(before_sort.values())
        enumeration = [str(doc.metadata['item_id']) for doc, _ in input_docs]
        scores = {str(doc.metadata['item_id']): float(s) for doc, s in sorted_scored}
        sorted_ids = [str(doc.metadata['item_id']) for doc, _ in sorted_scored]
        if len(enumeration) != len(set(enumeration)) or set(enumeration) != set(scores):
            raise InvalidEvidence('non-unique/incomplete candidate inputs')
        if len(sorted_ids) != len(enumeration) or retriever.k != self.target['k']:
            raise InvalidEvidence('sorting mismatch')
        if not all(math.isfinite(x) for x in scores.values()):
            raise InvalidEvidence('non-finite score')
        if iso(timestamp) != self.target['scoring_at']:
            raise InvalidEvidence('scoring clock mismatch')
        selected = sorted_ids[:retriever.k]
        if not all(str(d.metadata['item_id']) == ident for (d, _), ident in zip(sorted_scored, sorted_ids)):
            raise InvalidEvidence('unstable identity')
        frontier = crossing_frontier(scores, retriever.k)
        crossing = bool(frontier)
        common = {
            'v': 1,
            'kind': 'prepare',
            'scope': copy.deepcopy(self.target),
            'selector': SELECTOR,
            'upstream_sha256': UPSTREAM_SHA256,
            'candidate_count': len(scores),
            'score_commitment': score_commitment(scores),
            'selected_order': selected,
            'boundary_crossing': crossing,
        }
        # A full tie-class order is re-playable, but on an all-tied query
        # it degenerates to the full candidate trajectory. In that case the
        # trusted hook seals only the selected prefix. That is an attestation,
        # not independently checkable enumeration completeness.
        use_prefix = crossing and len(frontier) > max(2 * retriever.k, 8)
        selective = {**common, 'policy': 'attested-prefix' if use_prefix else 'conditional-boundary'}
        if crossing and not use_prefix:
            selective['boundary_order'] = [ident for ident in enumeration if ident in frontier]
        if use_prefix:
            selective['tie_class_size'] = len(frontier)
        full = {**common, 'policy': 'full-iteration-order', 'complete_candidate_order': enumeration}
        # Strongest query-known reference baseline: NO candidate hash, score
        # map, or tie data needs to be transmitted when producer is trusted.
        direct = {'v':1,'kind':'prepare','policy':'direct-exact-topk-reference',
                  'scope':copy.deepcopy(self.target),'selector':SELECTOR,
                  'upstream_sha256':UPSTREAM_SHA256,'selected_order':selected}
        # Preimages MUST be sampled before upstream updates timestamps; they are
        # held as a separate signed change receipt, not as a candidate trajectory.
        selected_records = [d for d, _ in sorted_scored[:retriever.k]]
        preimages = [{'id': str(d.metadata['item_id']),
                      'last_accessed_at': iso(d.metadata['last_accessed_at'])}
                     for d in selected_records]
        preimages_payload = {
            'v': 1, 'kind': 'preimage', 'scope': copy.deepcopy(self.target),
            # Bind this before-image journal to EXACTLY its signed prepare,
            # disallowing a same-scope signed journal from another selection.
            'prepare_sha256': digest(selective),
            'selected_old_access': preimages,
        }
        self.preimages = self.signer.sign(preimages_payload)
        self.payloads = {
            'selective': self.signer.sign(selective),
            'full': self.signer.sign(full),
            'direct': self.signer.sign(direct),
            'preimages': self.preimages,
        }
        self.scores = scores
        self.enumeration = enumeration
        if self.write_prepare is not None:
            self.write_prepare(self.payloads['selective'], self.preimages)

    def finalize(self, result):
        if self.payloads is None:
            raise RuntimeError('upstream selection hook never ran')
        actual = [str(d.metadata['item_id']) for d in result]
        prepared = self.payloads['selective']['payload']['selected_order']
        if actual != prepared:
            raise InvalidEvidence('actual return differs from prepared receipt')
        common = {
            'v': 1, 'kind': 'commit', 'scope': copy.deepcopy(self.target),
            'actual_order': actual,
            'prepare_sha256': digest(self.payloads['selective']['payload']),
        }
        commit = self.signer.sign(common)
        return CapturedRead(self.payloads['selective'], commit,
                            self.payloads['full'], self.payloads['direct'],
                            self.scores, actual, self.enumeration)


def independently_verify(target: dict, trusted_scores: dict[str, float],
                         actual_read_ids: list[str], prepare: dict, commit: dict,
                         public_b64: str) -> str:
    """Conditional exact-set verifier: ACCEPT, REJECT, UNVERIFIABLE.

    `trusted_scores` must be complete & correct for the asserted historical
    cut, independently authenticated (not simply parsed from the receipt).
    `actual_read_ids` must come from an independently authenticated audited
    read, possibly LATER than the signed reference execution.
    Ed25519 guarantees authenticity only with trusted unexposed private key.
    """
    try:
        p = verify_signature(prepare, public_b64)
        c = verify_signature(commit, public_b64)
        if p.get('scope') != target or c.get('scope') != target:
            raise InvalidEvidence('target mismatch')
        if p.get('kind') != 'prepare' or c.get('kind') != 'commit' or p.get('v') != 1:
            raise InvalidEvidence('invalid event type')
        if p.get('selector') != SELECTOR or p.get('upstream_sha256') != UPSTREAM_SHA256:
            raise InvalidEvidence('selector binding mismatch')
        if p.get('policy') not in ('conditional-boundary', 'attested-prefix', 'full-iteration-order', 'direct-exact-topk-reference'):
            raise InvalidEvidence('unknown capture policy')
        # prepare/commit bind the authenticated HISTORICAL REFERENCE execution;
        # external actual_read_ids belongs to the potentially different audited
        # read. It must be authenticated independently by the caller. Otherwise
        # the verifier could only return ACCEPT or UNVERIFIABLE, never REJECT.
        if c.get('prepare_sha256') != digest(p) or c.get('actual_order') != p.get('selected_order'):
            raise InvalidEvidence('reference prepare/commit mismatch')
        if len(set(actual_read_ids)) != len(actual_read_ids) or not set(actual_read_ids) <= set(trusted_scores):
            raise InvalidEvidence('invalid externally authenticated actual IDs')
        if len(actual_read_ids) != target['k'] or len(p.get('selected_order',[])) != target['k']:
            raise InvalidEvidence('invalid selected count')
        if len(set(p['selected_order'])) != len(p['selected_order']):
            raise InvalidEvidence('duplicate claimed reference')
        if not all(isinstance(x, str) for x in trusted_scores):
            raise InvalidEvidence('invalid candidate identities')
        policy = p['policy']
        if policy != 'direct-exact-topk-reference':
            if p.get('candidate_count') != len(trusted_scores):
                raise InvalidEvidence('candidate count mismatch')
            if p.get('score_commitment') != score_commitment(trusted_scores):
                raise InvalidEvidence('score reference not bound')
            frontier = crossing_frontier(trusted_scores, target['k'])
            if bool(frontier) != p.get('boundary_crossing'):
                raise InvalidEvidence('tie-necessity mismatch')
        else:
            frontier = set()
        if policy == 'conditional-boundary':
            if not frontier and 'boundary_order' in p:
                raise InvalidEvidence('redundant/malformed order')
            ref = expected_topk(trusted_scores, target['k'], p.get('boundary_order'))
        elif policy == 'attested-prefix':
            if not frontier or p.get('tie_class_size') != len(frontier) or 'boundary_order' in p:
                raise InvalidEvidence('invalid attested tie prefix metadata')
            # The signed selected prefix is an attestation by the trusted
            # PRE-MUTATION hook. It is NOT a separately verifiable ordering
            # proof against a malicious capture service; nor does it beat a
            # direct signed top-k reference in certificate size.
            threshold = sorted(trusted_scores.values(), reverse=True)[target['k']-1]
            higher = {i for i,s in trusted_scores.items() if s > threshold}
            winners = [i for i in p['selected_order'] if i in frontier]
            if len(winners) != target['k'] - len(higher) or len(set(winners)) != len(winners):
                raise InvalidEvidence('bad attested prefix')
            if set(p['selected_order']) != higher | set(winners):
                raise InvalidEvidence('prefix conflicts with trusted score order')
            ref = higher | set(winners)
        elif policy == 'full-iteration-order':
            full_order = p.get('complete_candidate_order')
            if not isinstance(full_order, list) or len(full_order) != len(trusted_scores) or set(full_order) != set(trusted_scores):
                raise InvalidEvidence('invalid full candidate trace')
            ref = set(sorted(full_order, key=lambda x: trusted_scores[x], reverse=True)[:target['k']])
        else:
            # Trivial query-known baseline: trusting the producer's directly
            # signed exact-set reference requires no independent tie replay.
            ref = set(p['selected_order'])
        return 'ACCEPT' if ref == set(actual_read_ids) else 'REJECT'
    except (InvalidEvidence, ValueError, KeyError, TypeError, AssertionError):
        return 'UNVERIFIABLE'


def load_instrumented_upstream(hook):
    raw = SRC.read_bytes()
    if hashlib.sha256(raw).hexdigest() != UPSTREAM_SHA256:
        raise InvalidEvidence('upstream pinned source hash mismatch')
    src = raw.decode('utf-8')
    if src.count(TARGET_LINE) != 1:
        raise InvalidEvidence('pinned pre-mutation hook insertion point mismatch')
    patched = src.replace(TARGET_LINE,
                          '        rescored_docs.sort(key=lambda x: x[1], reverse=True)\n'
                          '        _audit_capture(self, docs_and_scores, rescored_docs, current_time)\n'
                          '        result = []')
    mod = types.ModuleType('pinned_audited_retriever')
    mod.__file__ = str(SRC)
    mod._audit_capture = hook
    exec(compile(patched, str(SRC), 'exec'), mod.__dict__)
    return mod


def setup_core(prefer_real=True):
    """Prefer installed langchain_core; shims are explicit, isolated fallback."""
    # A prior shim-mode test may have populated sys.modules with modules
    # lacking __spec__. Calling find_spec on those raises ValueError. Never
    # misclassify an in-process shim as a real installed langchain-core.
    loaded = sys.modules.get('langchain_core')
    if loaded is not None and getattr(loaded, '__spec__', None) is None:
        docs = sys.modules.get('langchain_core.documents')
        store = sys.modules.get('langchain_core.vectorstores')
        if docs is not None and store is not None:
            return docs.Document, store.VectorStore, {
                'mode': 'PINNED_SOURCE_API_SHIMS', 'version': None, 'path': None}
    if prefer_real and importlib.util.find_spec('langchain_core'):
        from importlib import metadata
        from langchain_core.documents import Document
        from langchain_core.vectorstores import VectorStore
        import langchain_core
        return Document, VectorStore, {'mode': 'REAL_INSTALLED_CORE',
                                        'version': metadata.version('langchain-core'),
                                        'path': str(Path(langchain_core.__file__).resolve())}
    from pydantic import BaseModel, Field, ConfigDict
    def fake_module(name):
        obj = types.ModuleType(name)
        sys.modules[name] = obj
        return obj
    fake_module('langchain_core')
    cb = fake_module('langchain_core.callbacks')
    cb.CallbackManagerForRetrieverRun = type('CallbackManagerForRetrieverRun', (), {})
    cb.AsyncCallbackManagerForRetrieverRun = type('AsyncCallbackManagerForRetrieverRun', (), {})
    docs = fake_module('langchain_core.documents')
    class Document(BaseModel):
        page_content: str
        metadata: dict = Field(default_factory=dict)
    docs.Document = Document
    retr = fake_module('langchain_core.retrievers')
    class BaseRetriever(BaseModel):
        model_config = ConfigDict(arbitrary_types_allowed=True)
    retr.BaseRetriever = BaseRetriever
    store = fake_module('langchain_core.vectorstores')
    class VectorStore:
        pass
    store.VectorStore = VectorStore
    return Document, VectorStore, {'mode': 'PINNED_SOURCE_API_SHIMS', 'version': None, 'path': None}


def clock_class(frozen: dt.datetime):
    class Clock(dt.datetime):
        @classmethod
        def now(cls, tz=None):
            return frozen
    return Clock


def run_one(module, document_type, store_type, signer: Signer, *, scores: dict[str,float],
            enumeration: list[str], k: int, scope: dict, now: dt.datetime,
            last_age_hours: float = 2.0, ledger_path: Path | None = None) -> tuple[CapturedRead, dict]:
    if len(enumeration) != len(scores) or set(enumeration) != set(scores):
        raise ValueError('invalid enumeration')
    def persist_prepare(prepare, preimages):
        if ledger_path is None:
            return
        ledger_path.parent.mkdir(parents=True, exist_ok=True)
        with ledger_path.open('ab') as fout:
            for e in (prepare, preimages):
                fout.write(canonical(e) + b'\n')
            fout.flush()
            import os
            os.fsync(fout.fileno())
    rec = CaptureSession(signer, scope, persist_prepare)
    instrumented = load_instrumented_upstream(rec.pre_mutation_hook)
    instrumented.TimeWeightedVectorStoreRetriever.model_rebuild(
        _types_namespace=vars(instrumented))
    if module is not None and module != 'ignored':
        raise ValueError('call with module=None; instrumented loader owns module')
    class FixedScoreStore(store_type):
        def __init__(self, relevance):
            self.relevance = relevance
            self.docs = []
        def similarity_search_with_relevance_scores(self, query, **kwargs):
            lookup={str(d.metadata['item_id']):d for d in self.docs}
            return [(lookup[x],float(self.relevance[x])) for x in enumeration]
        def similarity_search(self, query, k=4, **kwargs):
            return [d for d,_ in self.similarity_search_with_relevance_scores(query)][:k]
        @classmethod
        def from_texts(cls,texts,embedding,metadatas=None,**kwargs):
            raise NotImplementedError
        def add_texts(self,texts,metadatas=None,**kwargs):
            raise NotImplementedError
    store = FixedScoreStore(scores)
    # The memory stream's last-k seed order is determined by enumeration, then
    # vectorstore results enrich / append, so choose memory stream order and
    # use k==1 for precision tests unless tests deliberately include seed docs.
    docs = [document_type(page_content=f'Memory {ident}', metadata={
        'item_id': ident, 'buffer_idx': idx,
        'last_accessed_at': now - dt.timedelta(hours=last_age_hours),
        'importance': 0.0,
    }) for idx, ident in enumerate(enumeration)]
    store.docs = docs
    ret = instrumented.TimeWeightedVectorStoreRetriever(
        vectorstore=store, memory_stream=docs, decay_rate=0.01, k=k,
        other_score_keys=['importance'],default_salience=None,search_kwargs={'k':len(docs)})
    before = {d.metadata['item_id']: iso(d.metadata['last_accessed_at']) for d in ret.memory_stream}
    with patch.object(instrumented.datetime, 'datetime', clock_class(now)):
        result = ret._get_relevant_documents('query', run_manager=None)
    captured = rec.finalize(result)
    after = {d.metadata['item_id']: iso(d.metadata['last_accessed_at']) for d in ret.memory_stream}
    assert all(after[x] == iso(now) for x in captured.upstream_returned)
    assert all(after[x] == before[x] for x in before if x not in captured.upstream_returned)
    if ledger_path is not None:
        with ledger_path.open('ab') as fout:
            fout.write(canonical(captured.commit) + b'\n')
            fout.flush()
            import os
            os.fsync(fout.fileno())
    return captured, {'before': before, 'after': after, 'mode': 'SOURCE_WITH_PREMUTATION_HOOK'}
