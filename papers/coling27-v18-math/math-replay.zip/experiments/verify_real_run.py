#!/usr/bin/env python3
"""Strict, offline, cross-read checker for an executed real LangChain transcript.

This verifies transcript *consistency*, not provenance of the actual installed
wheel, external truth of the oracle or trusted identity of the signer. An
attacker able to generate a NEW signing key and arbitrary fixture data can
satisfy these checks; CI execution provenance must be separately trusted.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from audited_retrieval import (UPSTREAM_SHA256, canonical, digest,
                               independently_verify, verify_signature)


def _load(path):
    return json.loads(path.read_text())


def check(root: Path, require_real: bool = True):
    root=Path(root)
    report=_load(root/'validation-report.json')
    assert report['mode']==('REAL_INSTALLED_CORE' if require_real else report['mode'])
    if require_real:
        assert report['version']=='0.3.83'
        assert report['real_vectorstore']=='InMemoryVectorStore'
        assert report['pinned_upstream_and_real_BaseRetriever_invoke'] is True
        assert report.get('core_invoke_count')==2
        assert report.get('vectorstore_search_count',0)==2
    assert report['continuous_signed_read_count']==2
    assert report['ledger_event_count']==6
    assert len(report['verified_reads'])==2
    assert hashlib.sha256((ROOT/'src/time_weighted_retriever.py').read_bytes()).hexdigest()==UPSTREAM_SHA256
    ledger_lines=(root/'two-read-ledger.jsonl').read_bytes().splitlines()
    assert len(ledger_lines)==6
    ledger=[json.loads(line) for line in ledger_lines]
    states=_load(root/'initial-state.json')
    assert set(states)=={'d0','d1','d2','d3'}
    current=states.copy()
    before_clocks=[]; ids=[]; keys=[]
    for i in (1,2):
        prefix=f'read-{i}-'
        subset=(root/(prefix+'ledger.jsonl')).read_bytes().splitlines()
        assert len(subset)==3
        assert subset==ledger_lines[3*(i-1):3*i], 'separate and global ledger differ'
        key=(root/(prefix+'public-key.b64')).read_text().strip()
        keys.append(key)
        events=ledger[3*(i-1):3*i]
        prep,pre,commit=(verify_signature(e,key) for e in events)
        assert [x.get('kind') for x in (prep,pre,commit)]==['prepare','preimage','commit']
        target=_load(root/(prefix+'target.json'))
        assert prep['scope']==pre['scope']==commit['scope']==target
        assert target['history_id']=='installed-core-h1' and target['read_id']==f'run-{i}'
        assert target['cut_id']==f'cut-{i}' and target['state_version']==f'state-{i}'
        assert target['k']==2 and target['query_sha256']==hashlib.sha256(b'query').hexdigest()
        assert prep['upstream_sha256']==UPSTREAM_SHA256
        assert pre['prepare_sha256']==commit['prepare_sha256']==digest(prep)
        assert prep['selected_order']==commit['actual_order']
        scope_id=(target['history_id'],target['read_id'])
        assert scope_id not in ids, 'duplicate read identity'
        ids.append(scope_id)
        before_clocks.append(dt.datetime.fromisoformat(target['scoring_at']))
        old=pre['selected_old_access']
        assert len(old)==target['k'] and [v['id'] for v in old]==prep['selected_order']
        assert all(x['last_accessed_at']==current[x['id']] for x in old), 'cross-read timestamp continuity failed'
        scores=_load(root/(prefix+'trusted-scores.json'))
        actual=_load(root/(prefix+'observed-return.json'))
        assert isinstance(actual,list) and actual==prep['selected_order']
        assert set(scores)==set(states)
        assert independently_verify(target,scores,actual,events[0],events[2],key)=='ACCEPT'
        assert report['verified_reads'][i-1]['selected']==actual
        assert report['verified_reads'][i-1]['verdict']=='ACCEPT'
        assert report['verified_reads'][i-1]['preimage_count']==len(old)
        for name in actual:
            current[name]=target['scoring_at']
    assert keys[0]==keys[1], 'key changed mid-history'
    assert before_clocks[0]<before_clocks[1], 'read clocks out of order'
    assert not any('SHIM' in str(x).upper() for x in [report['mode'],report['framework_path']])
    return {'status':'PASS_REAL_INSTALLED_CORE' if require_real else 'PASS_TRANSCRIPT_CONSISTENCY',
            'reads_verified':2,'signed_events_verified':6,
            'cross_read_selected_preimages_verified':4,
            'upstream_sha256':UPSTREAM_SHA256,
            'limitation':'signed fixture consistency; not third-party source or execution attestation'}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dir',type=Path,default=ROOT/'results/installed-core')
    path=parser.parse_args().dir
    print(json.dumps(check(path),indent=2))

if __name__=='__main__':
    main()
