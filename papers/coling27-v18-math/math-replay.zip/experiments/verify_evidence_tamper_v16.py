#!/usr/bin/env python3
"""Third-party-friendly structural check of v16 tamper campaign result rows.

The verifier does NOT infer that the 90 mutations actually happened solely
from JSON; independent reproductions must execute evidence_tamper_campaign.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

ERRORS={
'missing_commit','signed_prepare_payload_edit','preimage_replay_between_reads',
 'trusted_score_edit','target_scoring_clock_edit','cross_read_preimage_edit',
 'untrusted_content_edit','rehash_tool_chain_without_resigning',
 'cross_ticket_seal_substitution','action_request_edit','missing_read_snapshot',
 'aggregate_report_edit','verifier_key_substitution'
}
BENIGN={'episode_summary_reformat_control','unprotected_readme_control'}
TICKETS={f'T-{i:03d}' for i in (0,1,2,9,15,23)}

def verify(root:Path,source:Path):
 root=Path(root)
 s=json.loads((root/'summary.json').read_text())
 raw=(root/'per_mutation.jsonl').read_bytes()
 assert hashlib.sha256(raw).hexdigest()==s['per_mutation_sha256']
 assert hashlib.sha256((source/'agent-run-report.json').read_bytes()).hexdigest()==s['input_run_report_sha256']
 rows=[json.loads(line) for line in raw.splitlines()]
 assert len(rows)==90 and s['total_trials']==90
 assert set(s['malicious_classes'])==ERRORS and set(s['neutral_classes'])==BENIGN
 assert not s['real_langchain_executed'] and s['backend']=='PINNED_SOURCE_API_SHIMS'
 keys=Counter((row['ticket'],row['kind']) for row in rows)
 assert set(keys)=={(t,k) for t in TICKETS for k in ERRORS|BENIGN}
 assert all(c==1 for c in keys.values())
 bad=[]
 for row in rows:
  expected='REJECT' if row['kind'] in ERRORS else 'ACCEPT'
  assert row['expected']==expected
  assert row['actual']==expected and row['correct'] is True
  assert row['sha256_before']!=row['sha256_after']
  if row['kind'] in ERRORS:
   assert row['error'] is not None,'expected verifier exception evidence'
  else:
   assert row['error'] is None
  assert isinstance(row['path'],str) and row['path']
  assert not Path(row['path']).is_absolute() and '..' not in Path(row['path']).parts
 assert s['all_expectations_met'] is True
 assert s['malicious_cases']==78==s['malicious_rejections']
 assert s['controls']==12==s['neutral_accepts']
 return {'verdict':'PASS_FROZEN_TAMPER_CLAIMS',
         'synthetic_corruptions_confirmed_by_producer':78,
         'neutral_controls_confirmed_by_producer':12,
         'rows_verified':len(rows),
         'evidence_sha256':s['per_mutation_sha256'],
         'boundary':'validates complete arithmetic/claims in archived logs; independent rerun needed to establish generated mutation behavior'}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--dir',type=Path,default=Path('results/tamper-study-v16'));p.add_argument('--source',type=Path,default=Path('results/agent-shim-v15'));a=p.parse_args()
 print(json.dumps(verify(a.dir,a.source),indent=2))
