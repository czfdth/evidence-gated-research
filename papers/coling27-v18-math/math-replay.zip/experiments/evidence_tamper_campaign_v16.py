#!/usr/bin/env python3
"""Controlled tamper campaign on frozen v15 SHIM source-level synthetic traces.

This tests local verifier rejection behavior, not actual installed LangChain,
real adversaries, prompt-injection defenses, or protected external signer trust.
Each corruption starts from a freshly copied pristine snapshot; no production
artifact is modified. Per-case output is an append-only JSONL record.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
import tempfile
from collections import Counter
from pathlib import Path
from audited_retrieval import canonical
from experiments.verify_agent_run import check

ROOT=Path(__file__).resolve().parents[1]
DEFAULT=ROOT/'results'/'agent-shim-v15'
INDICES=(0,1,2,9,15,23)

def sha(data:bytes):return hashlib.sha256(data).hexdigest()
def dump_json(p:Path,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def new_content(path,content:bytes):
    before=path.read_bytes()
    if before==content:raise AssertionError('mutation is a no-op')
    path.write_bytes(content)
    return sha(before),sha(content)

def mutate(root:Path,ticket:str,kind:str):
    episode=root/'episodes'/ticket
    report=root/'agent-run-report.json'
    ledger=episode/'ledger.jsonl'
    tool=episode/'tool-trace.json'
    first=episode/'read-1.json'
    second=episode/'read-2.json'
    seal=episode/'signed-tool-trace-seal.json'
    if kind=='missing_commit':
        entries=ledger.read_bytes().splitlines();return str(ledger.relative_to(root)),new_content(ledger,b'\n'.join(entries[:-1])+b'\n')
    if kind=='signed_prepare_payload_edit':
        entries=[json.loads(line) for line in ledger.read_bytes().splitlines()]
        entries[0]['payload']['selected_order'][0]='forged-id'
        new=b''.join(canonical(x)+b'\n' for x in entries)
        return str(ledger.relative_to(root)),new_content(ledger,new)
    if kind=='preimage_replay_between_reads':
        entries=ledger.read_bytes().splitlines()
        entries[4]=entries[1]
        return str(ledger.relative_to(root)),new_content(ledger,b'\n'.join(entries)+b'\n')
    if kind=='trusted_score_edit':
        data=json.loads(first.read_text());k=next(iter(sorted(data['trusted_scores'])))
        data['trusted_scores'][k]+=100
        return str(first.relative_to(root)),new_content(first,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='target_scoring_clock_edit':
        data=json.loads(second.read_text());data['target']['scoring_at']='2001-01-01T00:00:00'
        return str(second.relative_to(root)),new_content(second,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='cross_read_preimage_edit':
        data=json.loads(second.read_text());k=next(iter(sorted(data['state_before'])))
        data['state_before'][k]='2001-01-01T00:00:00'
        return str(second.relative_to(root)),new_content(second,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='untrusted_content_edit':
        data=json.loads(tool.read_text());data[1]['response']['untrusted_text'][0]='forged instruction'
        return str(tool.relative_to(root)),new_content(tool,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='rehash_tool_chain_without_resigning':
        data=json.loads(tool.read_text());data[1]['response']['untrusted_text'][0]='forged instruction'
        prev='0'*64
        for step in data:
            step['prev_sha256']=prev
            raw={k:v for k,v in step.items() if k!='entry_sha256'}
            prev=sha(canonical(raw));step['entry_sha256']=prev
        return str(tool.relative_to(root)),new_content(tool,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='cross_ticket_seal_substitution':
        src=root/'episodes'/('T-000' if ticket!='T-000' else 'T-001')/'signed-tool-trace-seal.json'
        return str(seal.relative_to(root)),new_content(seal,src.read_bytes())
    if kind=='action_request_edit':
        data=json.loads(tool.read_text());data[-1]['args']['approved']=not data[-1]['args']['approved']
        return str(tool.relative_to(root)),new_content(tool,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='missing_read_snapshot':
        data=second.read_bytes();second.unlink();return str(second.relative_to(root)),(sha(data),None)
    if kind=='aggregate_report_edit':
        data=json.loads(report.read_text());data['approved_count']+=1
        return str(report.relative_to(root)),new_content(report,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='verifier_key_substitution':
        data=json.loads(report.read_text());data['public_key_b64']='AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA='
        return str(report.relative_to(root)),new_content(report,(json.dumps(data,indent=2)+'\n').encode())
    if kind=='episode_summary_reformat_control':
        p=episode/'episode-report.json';data=json.loads(p.read_text())
        return str(p.relative_to(root)),new_content(p,(json.dumps(data,sort_keys=True,separators=(',',':'))+'\n').encode())
    if kind=='unprotected_readme_control':
        p=root/'probe-note.txt';p.write_text('This README-style sidecar is not signed or part of the verifier input.\n')
        return str(p.relative_to(root)),(None,sha(p.read_bytes()))
    raise ValueError('unknown mutation '+kind)

MALICIOUS=[
    'missing_commit','signed_prepare_payload_edit','preimage_replay_between_reads',
    'trusted_score_edit','target_scoring_clock_edit','cross_read_preimage_edit',
    'untrusted_content_edit','rehash_tool_chain_without_resigning',
    'cross_ticket_seal_substitution','action_request_edit',
    'missing_read_snapshot','aggregate_report_edit','verifier_key_substitution',
]
CONTROLS=['episode_summary_reformat_control','unprotected_readme_control']

def run(source:Path,out:Path,indices=INDICES):
    source=Path(source);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    assert check(source,'shim')['verdict']=='PASS'
    record_path=out/'per_mutation.jsonl'
    count=Counter();records=[]
    # All changes isolated in independent snapshot directories. Copying the
    # original includes no private key: only public verification material.
    for idx in indices:
        ticket=f'T-{idx:03d}'
        for kind in MALICIOUS+CONTROLS:
            with tempfile.TemporaryDirectory(prefix='v16-tamper-') as temp:
                target=Path(temp)/'snapshot'
                shutil.copytree(source,target)
                rel,hashes=mutate(target,ticket,kind)
                try:
                    checked=check(target,'shim')
                    verdict='ACCEPT' if checked.get('verdict')=='PASS' else 'REJECT'
                    error=None
                except Exception as e:
                    verdict='REJECT'
                    error={'type':type(e).__name__,'message':str(e)[:160]}
                expected='REJECT' if kind in MALICIOUS else 'ACCEPT'
                row={'ticket':ticket,'kind':kind,'expected':expected,'actual':verdict,
                     'path':rel,'sha256_before':hashes[0],'sha256_after':hashes[1],
                     'error':error,'correct':verdict==expected}
                count[(kind,verdict)]+=1
                records.append(row)
    with record_path.open('w') as f:
        for row in records:f.write(json.dumps(row,sort_keys=True)+'\n')
    stats={
       'experiment':'v16_synthetic_trace_tamper_matrix',
       'backend':'PINNED_SOURCE_API_SHIMS','real_langchain_executed':False,
       'cases_per_kind':len(indices),'tamper_kinds':len(MALICIOUS),
       'neutral_controls':len(CONTROLS),'total_trials':len(records),
       'malicious_cases':len(MALICIOUS)*len(indices),
       'controls':len(CONTROLS)*len(indices),
       'malicious_rejections':sum(row['kind'] in MALICIOUS and row['actual']=='REJECT' for row in records),
       'neutral_accepts':sum(row['kind'] in CONTROLS and row['actual']=='ACCEPT' for row in records),
       'all_expectations_met':all(row['correct'] for row in records),
       'malicious_classes':MALICIOUS,'neutral_classes':CONTROLS,
       'input_run_report_sha256':sha((source/'agent-run-report.json').read_bytes()),
       'per_mutation_sha256':sha(record_path.read_bytes()),
       'limitation':'synthetic file tampering of a frozen source-shim trace: not a real attack test, production guarantee or installed LangChain benchmark'}
    dump_json(out/'summary.json',stats)
    if not stats['all_expectations_met']:
        raise AssertionError('some tamper or neutral controls behaved unexpectedly: '+str([r for r in records if not r['correct']][:3]))
    return stats

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,default=DEFAULT);p.add_argument('--out',type=Path,default=ROOT/'results'/'tamper-study-v16');a=p.parse_args()
    print(json.dumps(run(a.source,a.out),indent=2))
