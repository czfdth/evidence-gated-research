#!/usr/bin/env python3
"""Re-execute all v11 reconstructed experiments and diff each frozen JSON.

This only tests deterministic reproducibility of NEW synthetic fixtures; it
cannot recover original absent pilot data.
"""
import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FILES=['continuous-summary.json','dual-certificate-examples.json','lexical-corpus.json','lexical-summary.json','prospective-summary.json','run-manifest.json']
def check(reference, log=None):
    with tempfile.TemporaryDirectory(prefix='coling-v12-replay-') as td:
        command=[sys.executable,str(ROOT/'experiments/main_experiments.py'),'--experiment','all','--seeds','24','--claims','160','--out',td]
        proc=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=900)
        if proc.returncode:raise RuntimeError('re-execution failed: '+proc.stderr[-2000:])
        files={}
        for name in FILES:
            before=(Path(reference)/name).read_bytes();after=(Path(td)/name).read_bytes()
            assert before==after,f'byte mismatch: {name}'
            files[name]={'sha256':hashlib.sha256(before).hexdigest(),'bytes':len(before)}
        result={'status':'PASS_DETERMINISTIC_SYNTHETIC_REPLAY',
                'matching_artifact_count':len(files),'matching_files':files,
                'stdout':proc.stdout.strip(),
                'boundary':'Only new v11 synthetic study; earlier pilot inputs are absent'}
        if log:
            Path(log).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
        return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--reference',type=Path,default=ROOT/'results/main-v11');p.add_argument('--log',type=Path,default=ROOT/'docs/v12-deterministic-replay.json');a=p.parse_args()
    print(json.dumps(check(a.reference,a.log),indent=2))
