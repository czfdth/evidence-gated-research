#!/usr/bin/env python3
"""Re-execute reconstructed experiment, byte-compare substantive JSON artifacts,
and compare run manifest *semantically* to preserve honest environment versions.

Environment versions are expected to differ across Python hosts; this script
must not label the whole run-manifest JSON byte-identical when they differ.
"""
import argparse,hashlib,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
EXACT_FILES=['continuous-summary.json','dual-certificate-examples.json','lexical-corpus.json','lexical-summary.json','prospective-summary.json']

def check(reference,log=None):
    reference=Path(reference)
    with tempfile.TemporaryDirectory(prefix='coling-v18-independent-replay-') as tmp:
        command=[sys.executable,str(ROOT/'experiments/main_experiments.py'),
                 '--experiment','all','--seeds','24','--claims','160','--out',tmp]
        proc=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=900)
        if proc.returncode:
            raise RuntimeError('Experiment failed before comparison: '+proc.stderr[-1600:])
        files={}
        for name in EXACT_FILES:
            base=(reference/name).read_bytes();observed=(Path(tmp)/name).read_bytes()
            assert base==observed,f'Substantive numeric artifact changed: {name}'
            files[name]={'sha256':hashlib.sha256(base).hexdigest(),'bytes':len(base)}
        expected=json.loads((reference/'run-manifest.json').read_text())
        observed=json.loads((Path(tmp)/'run-manifest.json').read_text())
        for name in ('experiment','source_file_sha256','summary'):
            assert expected[name]==observed[name],f'Run manifest semantic difference: {name}'
        assert expected['environment']['langchain_status']==observed['environment']['langchain_status']
        # Environment metadata must show the *actual* versions and should not be falsified.
        status={'status':'PASS_SUBSTANTIVE_BYTES_AND_MANIFEST_SEMANTICS',
            'matching_substantive_json_count':len(files),'matching_substantive_files':files,
            'manifest_source_sha256':expected['source_file_sha256'],
            'manifest_semantic_fields_checked':['experiment','source_file_sha256','summary','environment.langchain_status'],
            'environment_reference':expected['environment'],
            'environment_reexecution':observed['environment'],
            'manifest_exact_bytes':(reference/'run-manifest.json').read_bytes()==(Path(tmp)/'run-manifest.json').read_bytes(),
            'stdout':proc.stdout.strip(),
            'limitations':'NEW synthetic v11 fixtures only; not original absent v10 pilot instances; differs from real-world data'}
        if log:
            Path(log).parent.mkdir(parents=True,exist_ok=True)
            Path(log).write_text(json.dumps(status,indent=2,ensure_ascii=False)+'\n')
        return status

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--reference',type=Path,default=ROOT/'results/main-v11')
    a.add_argument('--log',type=Path,default=ROOT/'docs/v18-independent-replay.json')
    args=a.parse_args();print(json.dumps(check(args.reference,args.log),indent=2))
