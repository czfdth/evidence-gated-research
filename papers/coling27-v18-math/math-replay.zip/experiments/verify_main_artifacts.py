#!/usr/bin/env python3
"""Offline v11 output checker, deliberately independent of the LP generator.
Recomputes weighted negative-certificate U with high-precision Decimal numbers.
Checks metadata/counts and available sklearn source hashes. No private keys.
"""
from __future__ import annotations
import argparse
from decimal import Decimal, getcontext
import hashlib
import json
from pathlib import Path
getcontext().prec=55
ROOT=Path(__file__).resolve().parents[1]

def d(x):return Decimal(str(x))
def get_json(p):return json.loads(Path(p).read_text())
def check(folder):
    root=Path(folder)
    manifest=get_json(root/'run-manifest.json')
    digest=hashlib.sha256((ROOT/'experiments/main_experiments.py').read_bytes()).hexdigest()
    assert manifest['source_file_sha256']==digest,'experiment source does not match manifest'
    counts={k:v['case_count'] for k,v in manifest['summary'].items()}
    assert counts=={'continuous':19200,'lexical':15120,'prospective':672000},counts
    c=get_json(root/'continuous-summary.json')
    assert c['total_claim_budget_cases']==19200
    assert c['dual_certificate_count']==sum(v['newly_rejected'] for v in c['budgets'].values())
    assert sum(map(int,c['negative_certificate_supports'].values()))==c['dual_certificate_count']
    assert all(v['independent_definite']+v['newly_rejected']==v['coupled_definite'] for v in c['budgets'].values())
    examples=get_json(root/'dual-certificate-examples.json')
    for item in examples:
        w=list(map(d,item['weights']));b=list(map(d,item['shift']))
        a=[[d(x) for x in row] for row in item['unknown_coefficients']]
        assert len(w)==len(b)==len(a)
        assert all(x>=0 for x in w)
        assert abs(sum(w)-1) < d('0.0000001')
        n=len(a[0])
        assert all(len(row)==n for row in a)
        bound=sum(x*y for x,y in zip(w,b))
        bound+=sum(max(Decimal(0),sum(w[i]*a[i][j] for i in range(len(a)))) for j in range(n))
        assert bound<d('-0.00000001'),f'unsound example: {bound}'
        assert abs(bound-d(item['upper_bound']))<d('0.000001')
    l=get_json(root/'lexical-summary.json')
    assert (l['n_passages'],l['n_queries'],l['n_topics'])==(112,42,14)
    assert l['total_dependent_decisions']==15120
    assert sum(v['total'] for v in l['by_group'].values())==15120
    assert all(v['coupled_definite']>=v['independent_definite'] for v in l['by_group'].values())
    corpus=get_json(root/'lexical-corpus.json')
    assert len(corpus['documents'])==112 and len(corpus['queries'])==42
    assert len(set(x['id'] for x in corpus['documents']))==112
    assert len(set(x['id'] for x in corpus['queries']))==42
    skcheck='not available'
    try:
        import sklearn
        loc=Path(sklearn.__file__).parent/'datasets'/'descr'
        assert all(hashlib.sha256((loc/name).read_bytes()).hexdigest()==h
                   for name,h in corpus['source_sha256'].items())
        skcheck='14 RST sources SHA-256 matched'
    except ImportError:pass
    p=get_json(root/'prospective-summary.json')
    assert p['total_evaluated_claims_excluding_random_repeats']==672000
    assert all(p['policy_regime_budget'][f'all__{regime}__B{B}']['mean_coverage_pct']==100.
        for regime in ('matched','shifted') for B in range(3,13))
    return {'status':'PASS_RECONSTRUCTED_EXPERIMENT_ARTIFACTS',
            'continuously_audited_claim_budget_cases':19200,
            'lexical_decisions':15120,'prospective_claim_evaluations':672000,
            'standalone_verified_negative_examples':len(examples),
            'lexical_source_provenance':skcheck,
            'real_langchain_integration':'NOT TESTED BY THIS CHECKER'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--dir',type=Path,default=ROOT/'results/main-v11')
    args=parser.parse_args()
    print(json.dumps(check(args.dir),indent=2))
