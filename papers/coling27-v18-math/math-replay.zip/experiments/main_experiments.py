#!/usr/bin/env python3
"""Reconstructed, independently runnable COLING-v11 main-paper EXPERIMENTS.

Provenance warning: these fixtures are newly generated from the *published
protocol*, not recovered original experiment inputs. Numbers MUST NOT be
presented as reproduction of the v10 manuscript tables.

No API shims or LangChain are used in these *mathematical* experiment studies.
For the separate strict real framework path run run_installed_core.py.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import platform
import re
from pathlib import Path

import numpy as np
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1]
SEEDS=24
CONTINUOUS_BUDGETS=[3,6,9,12,18]
LEXICAL_BUDGETS=[3,5,7,10,14]
EPS=1e-8


def to_json(p, payload):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(payload,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+'\n')


def affine_bounds(b, a, known):
    """Separate (conservative) exact interval per challenger margin."""
    rem=np.ones(a.shape[1],dtype=bool)
    for k in known: rem[k]=False
    shift=b+sum(a[:,k]*v for k,v in known.items())
    unknown=a[:,rem]
    lo=shift+np.minimum(unknown,0).sum(axis=1)
    hi=shift+np.maximum(unknown,0).sum(axis=1)
    return lo,hi,shift,unknown


def independent_verdict(lo,hi):
    if np.all(lo>EPS):return 'ACCEPT'
    if np.any(hi<-EPS):return 'REJECT'
    return 'UNVERIFIABLE'


def coupled_maximin(shift,unknown):
    """Maximize min_j m_j(z) over an honest box of unknown event values.

    A strictly negative optimum rules out an alleged top-1 winner, using the
    shared event variables. Zero/near-zero deliberately remains undecided.
    """
    m,d=unknown.shape
    if d==0:return float(np.min(shift))
    # Unknown individual comparisons that can never be violated need not be
    # included, but preserve all others: full candidate coverage is assumed.
    low=shift+np.minimum(unknown,0).sum(axis=1)
    high=shift+np.maximum(unknown,0).sum(axis=1)
    active=low <= EPS
    if not np.any(active):return float(np.min(low))
    if np.any(high < -EPS):return float(np.min(high))
    s=shift[active]; a=unknown[active]
    c=np.r_[np.zeros(d),-1.]
    aub=np.c_[-a,np.ones(len(s))]
    result=linprog(c,A_ub=aub,b_ub=s,bounds=[(0.,1.)]*d+[(None,None)],method='highs')
    if not result.success:raise RuntimeError('maximin LP failed '+result.message)
    return float(result.x[-1])


def dual_negative_certificate(shift,unknown):
    """Return a checkable minimax dual certificate, or None if non-negative.

    U(lambda)=sum lambda*b + sum_e max(0,sum lambda*a_e).
    The verifier recomputes this value without trusting the LP producer.
    """
    m,d=unknown.shape
    c=np.r_[shift, np.ones(d)]
    aub=np.c_[unknown.T,-np.eye(d)] if d else None
    bub=np.zeros(d) if d else None
    eq=np.r_[np.ones(m),np.zeros(d)].reshape(1,-1)
    res=linprog(c,A_ub=aub,b_ub=bub,A_eq=eq,b_eq=[1.],
                bounds=[(0.,None)]*(m+d),method='highs')
    if not res.success:raise RuntimeError('dual LP failed '+res.message)
    lam=res.x[:m]
    exact=float(lam@shift+np.maximum(lam@unknown,0).sum())
    assert abs(exact-res.fun)<2e-6
    if exact>=-EPS:return None
    return {'weights':lam,'upper_bound':exact,'support':int(np.count_nonzero(lam>1e-6))}


def verify_negative(shift,unknown,lam):
    if np.min(lam)<-1e-9 or abs(sum(lam)-1)>1e-7:return False
    upper=float(lam@shift+np.maximum(lam@unknown,0).sum())
    return upper < -EPS


def verify_claim(b,a,actual,known,need_certificate=True):
    assert a.ndim==2 and len(b)==a.shape[0] and len(actual)==a.shape[1]
    oracle='ACCEPT' if np.all(b+a@actual>EPS) else 'REJECT'
    lo,hi,shift,unknown=affine_bounds(b,a,known)
    base=independent_verdict(lo,hi)
    joint=base; certificate=None
    if base=='UNVERIFIABLE':
        optimum=coupled_maximin(shift,unknown)
        if optimum<-EPS:
            joint='REJECT'
            if need_certificate:
                certificate=dual_negative_certificate(shift,unknown)
                assert certificate and verify_negative(shift,unknown,certificate['weights'])
        # Positive certificates require ALL individual intervals > 0; no
        # generalized 'existential winning history means accept' shortcut.
    assert base=='UNVERIFIABLE' or base==oracle, (base,oracle)
    assert joint=='UNVERIFIABLE' or joint==oracle, (joint,oracle)
    return oracle,base,joint,certificate


def continuous_claim(rng,t,d=24):
    """Explicit synthetic challenge fixtures, not the original hidden seeds."""
    a=np.zeros((3,d)); b=np.zeros(3)
    i,j=rng.choice(d,2,replace=False)
    case=t%5
    if case==0:  # irreducible two-challenger infeasible box
        a[0,i]=1; b[0]=-.68
        a[1,i]=-1; b[1]=.32
        a[2,:]=0; b[2]=.2
    elif case==1:  # three-way Helly-style impossible claim
        a[0,i]=1; b[0]=-.7
        a[1,j]=1; b[1]=-.7
        a[2,i]=-1; a[2,j]=-1; b[2]=1.0
    elif case==2:  # unconditionally true
        b[:]=[.05,.1,.2]
        a[0,i]=.2; a[1,j]=.15
    elif case==3:  # correct or wrong according to realized history
        b[:]=[-.46,.25,.4];a[0,i]=1; a[1,j]=-.2
    else:  # shifted random margins, mixed unknown coupling
        b=rng.uniform(-.25,.5,size=3)
        a[:,i]=rng.uniform(-.5,.5,size=3)
        a[:,j]=rng.uniform(-.5,.5,size=3)
    return b,a


def run_continuous(out,seeds=SEEDS,claims=160):
    summary={'kind':'continuous_reconstruction_v11','provenance':'NEW deterministic synthetic inputs; NOT recovered v10 workload',
        'seeds':seeds,'claims_per_seed':claims,'budgets':{},'total_claim_budget_cases':0,
        'dual_certificate_count':0,'negative_certificate_supports':{},'original_v10_numbers_are_not_targets':True}
    raw=[]
    for seed in range(seeds):
        rng=np.random.default_rng(314159+seed)
        actual=rng.beta(2.,2.,24)
        instances=[continuous_claim(rng,t) for t in range(claims)]
        order=rng.permutation(24)
        for budget in CONTINUOUS_BUDGETS:
            key=str(budget)
            stat=summary['budgets'].setdefault(key,dict(audits=0,independent_definite=0,coupled_definite=0,
                                        newly_rejected=0,independent_accept=0,independent_reject=0,
                                        coupled_accept=0,coupled_reject=0))
            known={int(x):float(actual[x]) for x in order[:budget]}
            for t,(b,a) in enumerate(instances):
                oracle,base,joint,cert=verify_claim(b,a,actual,known)
                stat['audits']+=1
                stat['independent_definite']+=(base!='UNVERIFIABLE')
                stat['coupled_definite']+=(joint!='UNVERIFIABLE')
                stat['independent_accept']+=(base=='ACCEPT')
                stat['independent_reject']+=(base=='REJECT')
                stat['coupled_accept']+=(joint=='ACCEPT')
                stat['coupled_reject']+=(joint=='REJECT')
                if cert:
                    assert base=='UNVERIFIABLE' and joint=='REJECT'
                    stat['newly_rejected']+=1
                    summary['dual_certificate_count']+=1
                    sup=str(cert['support'])
                    summary['negative_certificate_supports'][sup]=summary['negative_certificate_supports'].get(sup,0)+1
                    if len(raw)<64:
                        raw.append(dict(seed=seed,claim=t,budget=budget,
                            shift=(b+sum(a[:,k]*v for k,v in known.items())).tolist(),
                            unknown_coefficients=np.delete(a,list(known),axis=1).tolist(),
                            weights=cert['weights'].tolist(),upper_bound=cert['upper_bound']))
                summary['total_claim_budget_cases']+=1
    for v in summary['budgets'].values():
        v['independent_coverage_pct']=round(100*v['independent_definite']/v['audits'],3)
        v['coupled_coverage_pct']=round(100*v['coupled_definite']/v['audits'],3)
    to_json(out/'continuous-summary.json',summary)
    to_json(out/'dual-certificate-examples.json',raw)
    return summary

# Original manuscript's handwritten queries were NOT included in v10.
# Newly authored descriptions are frozen in the emitted lexical dataset.
QUESTIONS={
'breast_cancer':['How many samples and features are in the breast cancer dataset?', 'What labels describe malignant and benign tumors?', 'Which predictive attributes characterize breast cancer diagnoses?'],
'california_housing':['What does the California housing dataset predict?', 'What are the geographic and housing features used?', 'How are median house values represented in housing data?'],
'covtype':['How is forest cover type classified?', 'Which wilderness areas and soil types are included?', 'What cartographic features describe forest cover?'],
'diabetes':['How is diabetes progression measured?', 'What baseline variables are used in diabetes prediction?', 'What response variable does the diabetes dataset contain?'],
'digits':['How many handwritten digit samples are available?', 'What is the digit image pixel resolution?', 'How are digits classified from images?'],
'iris':['What are the sepal and petal measurements?', 'How many iris flower species are involved?', 'What kind of classification is demonstrated with iris?'],
'kddcup99':['What network intrusion detection connections are described?', 'Which attack categories appear in KDD data?', 'What features summarize computer network connections?'],
'lfw':['How is labeled faces in the wild used?', 'Which face recognition and verification tasks are supported?', 'How are photographs of public figures organized?'],
'linnerud':['What exercise physiology variables are recorded?', 'Which features describe exercise performance?', 'What physiological measurements appear in the dataset?'],
'olivetti_faces':['How many grayscale Olivetti face photographs are included?', 'What face recognition samples does Olivetti include?', 'How are subjects and face images represented?'],
'rcv1':['How are Reuters newswire documents categorized?', 'What sparse features appear in Reuters text classification?', 'Which topic labels describe Reuters articles?'],
'species_distributions':['How are species occurrence locations modeled?', 'What ecological distribution data and predictors are available?', 'How can geographic species presence be predicted?'],
'twenty_newsgroups':['What topics are included in the twenty newsgroups text corpus?', 'How are documents preprocessed for text classification?', 'What train test split is provided for news articles?'],
'wine_data':['What chemical analysis features describe wines?', 'How many different wine classes are represented?', 'How are wine cultivars predicted from measurements?'],
}


def lexical_corpus(source_dir, save_to, desired=112):
    from sklearn.feature_extraction.text import TfidfVectorizer
    base=Path(source_dir)
    assert len(list(base.glob('*.rst')))==14
    topics=sorted(QUESTIONS)
    blocks={}
    sources={}
    for topic in topics:
        p=base/(topic+'.rst')
        src=p.read_bytes(); sources[p.name]=hashlib.sha256(src).hexdigest()
        text=src.decode('utf-8')
        # Explicit NEW normalization: strip directive/inline formatting and
        # tokenize words, rather than claiming to recover the old pipeline.
        text=re.sub(r'(?m)^\s*\.\.\s+\S+::[^\n]*$', ' ',text)
        text=re.sub(r'``|`|\*|\|',' ',text)
        words=re.findall(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*",text)
        chunks=[' '.join(words[i:i+46]) for i in range(0,len(words),46) if len(words[i:i+46])>=22]
        assert chunks,(topic,'missing passages')
        blocks[topic]=chunks
    # Balanced deterministic round-robin selection from each topic until 112.
    docs=[]
    while len(docs)<desired:
        before=len(docs)
        for topic in topics:
            cursor=sum(x['topic']==topic for x in docs)
            if cursor<len(blocks[topic]):
                docs.append({'id':f'{topic}-{cursor:03d}','topic':topic,'text':blocks[topic][cursor]})
            if len(docs)==desired:break
        if len(docs)==before:raise RuntimeError('insufficient description text')
    queries=[{'id':f'{topic}-q{i}','topic':topic,'text':txt}
             for topic in topics for i,txt in enumerate(QUESTIONS[topic])]
    data={'schema':'v11-NEW-FIXTURES','source_library':'scikit-learn description RST',
          'normalization':'regex tokenization; 46-word chunks; tails >=22; balanced round-robin first 112',
          'source_sha256':sources,'documents':docs,'queries':queries,
          'different_from_v10_unavailable_frozen_queries':True}
    to_json(save_to,data)
    return data


def run_lexical(out,source_dir,seeds=SEEDS):
    from sklearn.feature_extraction.text import TfidfVectorizer
    corpus=lexical_corpus(source_dir,out/'lexical-corpus.json')
    docs=corpus['documents'];queries=corpus['queries']
    vectorizer=TfidfVectorizer(stop_words='english',ngram_range=(1,2),sublinear_tf=True)
    matrix=vectorizer.fit_transform([d['text'] for d in docs]); qvec=vectorizer.transform([q['text'] for q in queries])
    rel=(qvec@matrix.T).toarray(); topics=sorted(QUESTIONS)
    ti=np.array([topics.index(d['topic']) for d in docs],dtype=int)
    coef=np.array([.16+.28*(int(hashlib.sha256(d['id'].encode()).hexdigest()[:8],16)%10001)/10000. for d in docs])
    held={'covtype','lfw','rcv1','wine_data'}
    train_ids=[i for i,q in enumerate(queries) if q['topic'] not in held]
    # Before hidden factor realizations, forecast and frequency policies use
    # only the public, older topic-specific query features.
    topic_features=np.array([sum(float(np.max(rel[i,ti==g])) for i in train_ids) for g in range(14)])
    topdoc_count=np.array([sum(ti[int(np.argmax(rel[i]))]==g for i in train_ids) for g in range(14)])
    forecast_order=np.lexsort((np.arange(14),-topic_features))
    frequency_order=np.lexsort((np.arange(14),-topdoc_count))
    A=np.zeros((len(docs),14)); A[np.arange(len(docs)),ti]=coef
    counts={}
    total=0
    for seed in range(seeds):
        rng=np.random.default_rng(271828+seed)
        z=rng.beta(2,2,14)
        random_order=rng.permutation(14)
        for qi,q in enumerate(queries):
            s=.52*rel[qi]+A@z
            ranking=np.argsort(-s,kind='stable')
            claim=int(ranking[0] if (seed+qi)%2==0 else ranking[1])
            other=np.array([i for i in range(len(docs)) if i!=claim])
            b=.52*(rel[qi,claim]-rel[qi,other])
            ma=A[claim][None,:]-A[other]
            regime='held_out' if q['topic'] in held else 'seen'
            for budget in LEXICAL_BUDGETS:
                for policy,order in [('forecast',forecast_order),('frequency',frequency_order),('random',random_order)]:
                    selected=order[:budget]
                    known={int(k):float(z[k]) for k in selected}
                    oracle,base,joint,cert=verify_claim(b,ma,z,known,need_certificate=False)
                    label=f'{regime}__{policy}__B{budget}'
                    row=counts.setdefault(label,dict(total=0,independent_definite=0,coupled_definite=0,
                        independently_accepted=0,independently_rejected=0,coupled_accepted=0,coupled_rejected=0,newly_rejected=0))
                    row['total']+=1
                    row['independent_definite']+=(base!='UNVERIFIABLE')
                    row['coupled_definite']+=(joint!='UNVERIFIABLE')
                    row['independently_accepted']+=(base=='ACCEPT')
                    row['independently_rejected']+=(base=='REJECT')
                    row['coupled_accepted']+=(joint=='ACCEPT')
                    row['coupled_rejected']+=(joint=='REJECT')
                    row['newly_rejected']+=(base=='UNVERIFIABLE' and joint=='REJECT')
                    total+=1
    for row in counts.values():
        row['independent_coverage_pct']=round(100*row['independent_definite']/row['total'],2)
        row['coupled_coverage_pct']=round(100*row['coupled_definite']/row['total'],2)
    summary={'kind':'lexical_reconstruction_v11','provenance':'NEW queries and normalization; NOT source of original v10 numeric claims',
             'sklearn_version':__import__('sklearn').__version__,'n_passages':len(docs),'n_queries':len(queries),
             'n_topics':len(topics),'seeds':seeds,'held_out_topics':sorted(held),'budgets':LEXICAL_BUDGETS,
             'total_dependent_decisions':total,'capture_orders':{'forecast':forecast_order.tolist(),
             'frequency':frequency_order.tolist()},'by_group':counts}
    to_json(out/'lexical-summary.json',summary)
    return summary


def prospective_query(rng, topic):
    """A synthetic top-1 decision schema whose old values are all z_e=1.

    Accept requires hitting EVERY evidence group; reject needs one witnessed
    historical event. This implements the exact restricted score-family logic
    in the paper, but is NOT the original unseen benchmark query generator.
    """
    domain=list(range(0,12) if topic==0 else range(12,24))
    if rng.random()<.5:
        groups=[frozenset(int(x) for x in rng.choice(domain,int(rng.integers(2,5)),replace=False))
                for _ in range(int(rng.integers(2,5)))]
        return {'polarity':'accept','topic':topic,'groups':groups}
    return {'polarity':'reject','topic':topic,
            'groups':[frozenset(int(x) for x in rng.choice(domain,int(rng.integers(2,5)),replace=False))]}


def prospective_score(queries,captured,surrogate=False):
    S=set(captured)
    value=0.
    for q in queries:
        hits=[bool(S & g) for g in q['groups']]
        if q['polarity']=='reject':value+=int(hits[0])
        elif surrogate:value+=sum(hits)/len(hits)
        else:value+=int(all(hits))
    return value/len(queries) if queries else 0.


def prospective_order(train,policy):
    available=set(range(24));selected=[]
    if policy=='frequency':
        freqs={e:sum(sum(e in g for g in q['groups']) for q in train) for e in available}
        return sorted(available,key=lambda x:(-freqs[x],x))
    for step in range(24):
        base=prospective_score(train,selected,surrogate=(policy!='true_greedy'))
        def gain(e):
            candidate=selected+[e]
            if policy=='true_greedy':return prospective_score(train,candidate)-base
            if policy=='surrogate':return prospective_score(train,candidate,True)-base
            if policy=='balanced':
                topic0=[q for q in train if q['topic']==0]
                topic1=[q for q in train if q['topic']==1]
                v0=prospective_score(topic0,candidate,True)
                v1=prospective_score(topic1,candidate,True)
                return .5*prospective_score(train,candidate,True)+.5*min(v0,v1)
            raise ValueError(policy)
        winner=max(sorted(available),key=lambda e:(gain(e),-e))
        selected.append(winner);available.remove(winner)
    return selected


def run_prospective(out,seeds=SEEDS,random_trials=16):
    """Reconstructed 24-event forward capture policy comparison.

    The retention ranking uses training schemas only; never sees old values or
    held-out claims. Every claim is evaluated against both future regimes.
    """
    budgets=list(range(3,13)); accum={}
    for seed in range(seeds):
        rng=np.random.default_rng(161803+seed)
        def make_batch(n,rare_topic_prob):
            return [prospective_query(rng,int(rng.random()<rare_topic_prob)) for _ in range(n)]
        train=make_batch(120,.2)
        matched=make_batch(200,.2)
        shifted=make_batch(200,.8)
        order={p:prospective_order(train,p) for p in ('frequency','true_greedy','surrogate','balanced')}
        order['arrival']=list(range(24))
        random_orders=[list(map(int,rng.permutation(24))) for _ in range(random_trials)]
        for budget in budgets:
            for policy in ('arrival','frequency','true_greedy','surrogate','balanced','random','all'):
                selections=([list(range(24))] if policy=='all' else
                            [o[:budget] for o in random_orders] if policy=='random' else
                            [order[policy][:budget]])
                for regime,qs in [('matched',matched),('shifted',shifted)]:
                    value=np.mean([prospective_score(qs,S) for S in selections])
                    k=f'{policy}__{regime}__B{budget}'
                    accum.setdefault(k,[]).append(float(value))
    final={k:{'mean_coverage_pct':round(100*float(np.mean(v)),2),
               'min_seed_coverage_pct':round(100*min(v),2),
               'max_seed_coverage_pct':round(100*max(v),2),
               'number_of_seed_units':len(v)} for k,v in sorted(accum.items())}
    result={'kind':'prospective_reconstruction_v11',
        'provenance':'NEW topic-conditional synthetic schema; NOT original v10 query templates',
        'seeds':seeds,'event_count':24,'training_queries_per_seed':120,
        'held_out_queries_per_seed_per_regime':200,'random_subsets_per_seed':random_trials,
        'budgets':budgets,'policy_regime_budget':final,
        'total_evaluated_claims_excluding_random_repeats':seeds*200*2*len(budgets)*7}
    to_json(out/'prospective-summary.json',result)
    return result


def environment():
    import scipy,sklearn
    return {'python':platform.python_version(),'numpy':np.__version__,
            'scipy':scipy.__version__,'scikit_learn':sklearn.__version__,
            'langchain_status':'NOT USED; strict installed integration tested separately'}


def main():
    import sklearn
    p=argparse.ArgumentParser()
    p.add_argument('--experiment',choices=['continuous','lexical','prospective','all'],default='all')
    p.add_argument('--out',type=Path,default=ROOT/'results'/'main-v11')
    p.add_argument('--seeds',type=int,default=SEEDS)
    p.add_argument('--claims',type=int,default=160)
    p.add_argument('--source-dir',type=Path,default=Path(sklearn.__file__).parent/'datasets'/'descr')
    args=p.parse_args()
    if args.seeds<=0 or args.claims<=0:raise SystemExit('positive seeds/claims required')
    args.out.mkdir(parents=True,exist_ok=True)
    summaries={}
    if args.experiment in ('continuous','all'):
        summaries['continuous']=run_continuous(args.out,args.seeds,args.claims)
    if args.experiment in ('lexical','all'):
        summaries['lexical']=run_lexical(args.out,args.source_dir,args.seeds)
    if args.experiment in ('prospective','all'):
        summaries['prospective']=run_prospective(args.out,args.seeds)
    to_json(args.out/'run-manifest.json',dict(experiment=args.experiment,environment=environment(),
        source_file_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        summary={k:{'case_count':v.get('total_claim_budget_cases',v.get('total_dependent_decisions',v.get('total_evaluated_claims_excluding_random_repeats'))),
                    'provenance':v['provenance']} for k,v in summaries.items()}))
    print(json.dumps({'out':str(args.out),'experiments':list(summaries),
       'case_counts':{k:v.get('total_claim_budget_cases',v.get('total_dependent_decisions',v.get('total_evaluated_claims_excluding_random_repeats'))) for k,v in summaries.items()}},indent=2))

if __name__=='__main__':main()
