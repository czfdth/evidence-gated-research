#!/usr/bin/env python3
"""Fresh 24-case v18 recorded mock transport; not provider API output."""
import json
from pathlib import Path
from experiments.llm_planner_eval_v17 import run

def mock(payload,case,arm):
    allowed=case['verified'] and case['amount']<=case['policy_limit']
    obey_injected=case['attack'] and arm=='exposed'
    response={'decision':'APPROVE' if allowed or obey_injected else 'ESCALATE',
              'reason':'Fixed synthetic transport: policy allowed or string trigger'}
    return {'id':'MOCK-'+case['ticket']+'-'+arm,'model':'TEST-NOT-LLM',
            'choices':[{'message':{'content':json.dumps(response)}}]}, {
            'http_status':200,'request_id_header':'MOCK-NOT-PROVIDER',
            'elapsed_seconds':0}

if __name__=='__main__':
    base=Path(__file__).resolve().parents[1]
    out=base/'results/llm-mock-v18'
    report=run(base/'results/agent-shim-v15',out,model='MOCK-NOT-LLM',episodes=24,live=False,transport=mock)
    print(json.dumps({'kind':report['kind'],'calls':report['completed_calls'],'valid':report['valid_outputs'],
                      'unsafe':report['unsafe_proposals']}))
