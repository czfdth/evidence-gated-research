#!/usr/bin/env python3
"""Independent Decimal-only audit of ALL retained negative dual witnesses.

Does not import the source generator, NumPy, SciPy, or the LP optimizer.
High-precision recomputation checks certificate *arithmetic* conditional on
trusted coefficient/candidate/cut provenance. It cannot prove those inputs true.
"""
from __future__ import annotations
import argparse
from collections import Counter
from decimal import Decimal, localcontext
import gzip
import hashlib
import json
from pathlib import Path


def decimal(x):
    return Decimal(str(x))


def audit(root:Path, reference:Path):
    root=Path(root)
    manifest=json.loads((root/'full-certificate-manifest.json').read_text())
    source=(reference/'continuous-summary.json').read_bytes()
    assert hashlib.sha256(source).hexdigest()==manifest['source_continuous_summary_sha256']
    reference_summary=json.loads(source)
    archive=(root/'all-4401-negative-certificates.jsonl.gz').read_bytes()
    assert hashlib.sha256(archive).hexdigest()==manifest['full_certificate_sha256']
    counts=Counter();supports=Counter(); seen=set();tightest=None
    with localcontext() as ctx:
        ctx.prec=70
        with gzip.open(root/'all-4401-negative-certificates.jsonl.gz','rt',encoding='utf-8') as f:
            for line in f:
                cert=json.loads(line)
                identity=(cert['seed'],cert['claim'],cert['budget'])
                assert identity not in seen,'duplicate certificate'
                seen.add(identity)
                assert 0<=cert['seed']<24 and 0<=cert['claim']<160
                assert cert['budget'] in (3,6,9,12,18)
                assert cert['oracle']=='REJECT' and cert['independent']=='UNVERIFIABLE' and cert['joint']=='REJECT'
                w=[decimal(x) for x in cert['weights']]
                shift=[decimal(x) for x in cert['shift']]
                A=[[decimal(x) for x in row] for row in cert['unknown_coefficients']]
                assert len(w)==len(shift)==len(A)==3
                n=24-cert['budget']
                assert all(len(row)==n for row in A)
                assert all(-Decimal('1e-10')<=wi<=1+Decimal('1e-10') for wi in w)
                assert abs(sum(w)-1)<Decimal('1e-7')
                support=sum(wi>Decimal('1e-6') for wi in w)
                assert support==cert['support']
                upper=sum(wi*si for wi,si in zip(w,shift))
                upper+=sum(max(Decimal(0),sum(w[i]*A[i][j] for i in range(3))) for j in range(n))
                assert upper<Decimal('-1e-8'), (identity,upper)
                assert abs(upper-decimal(cert['upper_bound']))<Decimal('1e-6')
                if tightest is None or upper>tightest:tightest=upper
                counts[cert['budget']]+=1
                supports[str(support)]+=1
    expected={int(k):v['newly_rejected'] for k,v in reference_summary['budgets'].items()}
    assert dict(counts)==expected=={int(k):v for k,v in manifest['by_budget'].items()}
    assert dict(supports)==manifest['by_support']==reference_summary['negative_certificate_supports']
    assert len(seen)==manifest['certificate_count']==reference_summary['dual_certificate_count']==4401
    return {
        'status':'PASS_ALL_4401_DECIMAL_NEGATIVE_CERTIFICATES',
        'checked':len(seen),'per_budget':{str(k):counts[k] for k in sorted(counts)},
        'support_histogram':dict(sorted(supports.items())),
        'least_negative_recomputed_bound':str(tightest),
        'archive_sha256':manifest['full_certificate_sha256'],
        'limitations':'Checks all weighted inequalities with Decimal; coefficient/candidate/cut provenance remains an assumption; not installed LangChain or recovered pilots'}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--dir',type=Path,default=Path('results/v13-full-certificate-audit'))
    p.add_argument('--reference',type=Path,default=Path('results/main-v11'))
    args=p.parse_args()
    print(json.dumps(audit(args.dir,args.reference),indent=2))

if __name__=='__main__':main()
