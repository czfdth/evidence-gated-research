#!/usr/bin/env python3
"""Emit ALL synthetic continuous-study negative certificates for independent audit.

Producer uses the inherited generator/LP, but the verifier below uses Decimal
and does NOT run an LP or import its solver. Not a recovery of v10 pilots.
"""
from __future__ import annotations
import argparse
from collections import Counter
from decimal import Decimal, localcontext
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from experiments.main_experiments import (
    SEEDS, CONTINUOUS_BUDGETS, EPS, continuous_claim, affine_bounds,
    independent_verdict, coupled_maximin, dual_negative_certificate,
)


def compact(o):
    return json.dumps(o,sort_keys=True,separators=(',',':'),allow_nan=False)


def produce(root: Path, source: Path):
    root.mkdir(parents=True, exist_ok=True)
    reference=json.loads((source/'continuous-summary.json').read_text())
    counts=Counter(); supports=Counter(); examples=[]; n_cases=0
    output=root/'all-4401-negative-certificates.jsonl.gz'
    with output.open('wb') as raw:
        # Store gzip without a run-dependent filename/timestamp.
        with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as fout:
            for seed in range(SEEDS):
                rng=np.random.default_rng(314159+seed)
                actual=rng.beta(2.,2.,24)
                cases=[continuous_claim(rng,t) for t in range(160)]
                order=rng.permutation(24)
                for budget in CONTINUOUS_BUDGETS:
                    known={int(x):float(actual[x]) for x in order[:budget]}
                    for idx,(b,a) in enumerate(cases):
                        n_cases+=1
                        lo,hi,shift,unknown=affine_bounds(b,a,known)
                        base=independent_verdict(lo,hi)
                        oracle='ACCEPT' if np.all(b+a@actual>EPS) else 'REJECT'
                        if base != 'UNVERIFIABLE':
                            assert base==oracle
                            continue
                        optimum=coupled_maximin(shift,unknown)
                        if optimum >= -EPS: continue
                        assert oracle=='REJECT'
                        cert=dual_negative_certificate(shift,unknown)
                        assert cert is not None
                        counts[budget]+=1
                        supports[str(cert['support'])]+=1
                        example={
                            'seed':seed,'claim':idx,'budget':budget,'oracle':oracle,
                            'independent':base,'joint':'REJECT',
                            'shift':[float(x) for x in shift],
                            'unknown_coefficients':unknown.tolist(),
                            'weights':[float(x) for x in cert['weights']],
                            'upper_bound':float(cert['upper_bound']),
                            'support':int(cert['support'])}
                        line=compact(example).encode()+b'\n'
                        fout.write(line)
    expected={int(k):v['newly_rejected'] for k,v in reference['budgets'].items()}
    assert dict(counts)==expected,(counts,expected)
    assert dict(supports)==reference['negative_certificate_supports']
    assert sum(counts.values())==reference['dual_certificate_count']==4401
    assert n_cases==reference['total_claim_budget_cases']==19200
    stats={
        'provenance':'NEW v11/v12 reconstructed synthetic study; NOT original v10 pilot',
        'producer':'experiments/full_certificate_audit.py',
        'verifier':'experiments/verify_all_certificates.py',
        'case_count':n_cases,'certificate_count':sum(counts.values()),
        'by_budget':{str(k):v for k,v in sorted(counts.items())},
        'by_support':dict(sorted(supports.items())),
        'full_certificate_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
        'full_certificate_bytes':output.stat().st_size,
        'source_continuous_summary_sha256':hashlib.sha256((source/'continuous-summary.json').read_bytes()).hexdigest(),
    }
    (root/'full-certificate-manifest.json').write_text(json.dumps(stats,indent=2,sort_keys=True)+'\n')
    return stats


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--out',type=Path,default=Path('results/v13-full-certificate-audit'))
    p.add_argument('--reference',type=Path,default=Path('results/main-v11'))
    args=p.parse_args()
    print(json.dumps(produce(args.out,args.reference),indent=2))

if __name__=='__main__':main()
