#!/usr/bin/env python3
"""Sequential event-time audit adapter for the pinned upstream retriever.

This is an experimental adapter, NOT a transactional retriever or a secure
signing service. Explicitly uses langchain_core.BaseRetriever.invoke if a REAL
installed package is present; source shims are supported for unit tests only.
Clock freezing uses a process-wide datetime patch: TEST ONLY, NOT thread safe.
"""
from __future__ import annotations

import copy
import datetime as dt
import hashlib
import json
import os
import threading
from pathlib import Path
from unittest.mock import patch

from audited_retrieval import (
    CaptureSession, InvalidEvidence, Signer, canonical, clock_class, iso,
    load_instrumented_upstream, setup_core, verify_signature, digest, UPSTREAM_SHA256,
)


class AuditedLifecycle:
    def __init__(self, *, vectorstore, memory_stream, k: int, signer: Signer,
                 ledger_path: Path, search_kwargs: dict, prefer_real=True):
        self.document_type, self.vectorstore_type, self.environment = setup_core(prefer_real)
        if prefer_real and self.environment['mode'] != 'REAL_INSTALLED_CORE':
            raise RuntimeError('A real installed langchain_core is required; shims refused')
        self.signer = signer
        self.ledger_path = Path(ledger_path)
        self._session = None
        self._lock = threading.Lock()
        self._used = set()
        self._expected_restored_times = {}
        self._tainted = False
        self._validate_existing_ledger()
        self.instrumented = load_instrumented_upstream(self._pre_mutation)
        self.instrumented.TimeWeightedVectorStoreRetriever.model_rebuild(
            _types_namespace=vars(self.instrumented))
        self.retriever = self.instrumented.TimeWeightedVectorStoreRetriever(
            vectorstore=vectorstore, memory_stream=memory_stream, decay_rate=.01,
            k=k, other_score_keys=['importance'], default_salience=None,
            search_kwargs=search_kwargs,
        )

    def _validate_existing_ledger(self):
        """Fail closed on an incomplete or foreign-key persisted history.

        Crash recovery must be done explicitly against trusted state; this
        adapter never silently resumes an incomplete signed read.
        """
        if not self.ledger_path.exists():
            return
        lines=[line for line in self.ledger_path.read_bytes().splitlines() if line.strip()]
        if len(lines)%3:
            raise InvalidEvidence('incomplete persisted transaction; manual recovery required')
        for i in range(0,len(lines),3):
            try:
                envelopes=[json.loads(x) for x in lines[i:i+3]]
                p,o,c=[verify_signature(x,self.signer.public_b64()) for x in envelopes]
                if [v.get('kind') for v in (p,o,c)] != ['prepare','preimage','commit']:
                    raise InvalidEvidence('invalid persisted event order')
                if p.get('upstream_sha256') != UPSTREAM_SHA256:
                    raise InvalidEvidence('different upstream source hash')
                if not p.get('scope') or p['scope'] != o.get('scope') or p['scope'] != c.get('scope'):
                    raise InvalidEvidence('persisted scope mismatch')
                if o.get('prepare_sha256')!=digest(p) or c.get('prepare_sha256')!=digest(p):
                    raise InvalidEvidence('persisted event digest mismatch')
                if p.get('selected_order') != c.get('actual_order'):
                    raise InvalidEvidence('persisted result mismatch')
                rid=(p['scope'].get('history_id'),p['scope'].get('read_id'))
                if not all(isinstance(x,str) and x for x in rid) or rid in self._used:
                    raise InvalidEvidence('duplicate or invalid persisted read identity')
                self._used.add(rid)
                when=p['scope'].get('scoring_at')
                if not isinstance(when,str) or not when:
                    raise InvalidEvidence('persisted scoring clock absent')
                for selected_id in c['actual_order']:
                    self._expected_restored_times[selected_id]=when
            except InvalidEvidence:
                raise
            except (ValueError, KeyError, TypeError) as exc:
                raise InvalidEvidence('untrusted or malformed persisted ledger') from exc

    def _pre_mutation(self, retriever, before_sort, sorted_scored, timestamp):
        if self._session is None:
            raise InvalidEvidence('retriever ran outside an authenticated read session')
        self._session.pre_mutation_hook(retriever, before_sort, sorted_scored, timestamp)

    def _append_fsync(self, *envelopes):
        self.ledger_path.parent.mkdir(parents=True, exist_ok=True)
        with self.ledger_path.open('ab') as fd:
            for e in envelopes:
                fd.write(canonical(e) + b'\n')
            fd.flush()
            os.fsync(fd.fileno())

    def _persist_prepare(self, prepare, preimages):
        # An I/O exception stops the upstream method before it updates timestamps.
        self._append_fsync(prepare, preimages)

    def read(self, query: str, target: dict, *, frozen_clock: dt.datetime | None = None,
             inject_failure_after_return: bool = False):
        """Capture one sync Runnable read. Runtime clock injection is TEST ONLY.

        The receipt commits only after the upstream method has returned. A fault
        after return (or a crash before commit) leaves a prepare without commit.
        This is fail-closed for the verifier, but state may already be mutated.
        """
        if self._tainted:
            raise InvalidEvidence('lifecycle tainted by a prior failure; recover explicitly')
        if not self._lock.acquire(blocking=False):
            raise RuntimeError('concurrent reads refused; no concurrency guarantee')
        try:
            if not isinstance(query, str) or target.get('query_sha256') != hashlib.sha256(query.encode()).hexdigest():
                raise InvalidEvidence('query hash is not bound to the actual invocation')
            if target.get('k') != self.retriever.k:
                raise InvalidEvidence('wrong k')
            if frozen_clock is not None and target.get('scoring_at') != iso(frozen_clock):
                raise InvalidEvidence('wrong scoring clock')
            rid = (target.get('history_id'), target.get('read_id'))
            if not all(isinstance(x, str) and x for x in rid) or rid in self._used:
                raise InvalidEvidence('missing/repeated history or read identity')
            # Reopening a valid ledger with an un-restored in-memory state is
            # unsafe: it would create a signed but cross-read-incompatible log.
            if self._expected_restored_times:
                memories={str(d.metadata.get('item_id')):d for d in self.retriever.memory_stream}
                for item, expected in self._expected_restored_times.items():
                    if item not in memories or iso(memories[item].metadata['last_accessed_at'])!=expected:
                        raise InvalidEvidence('restored memory timestamps disagree with persisted committed reads')
            # A failed read ID may not be reused in this process; prepare from a
            # failed previous run is not automatically abandoned or repaired.
            self._used.add(rid)
            session = CaptureSession(self.signer, copy.deepcopy(target), self._persist_prepare)
            self._session = session
            try:
                def invoke():
                    if self.environment['mode'] == 'REAL_INSTALLED_CORE':
                        # Executes the actual installed BaseRetriever Runnable path.
                        return self.retriever.invoke(query)
                    return self.retriever._get_relevant_documents(query, run_manager=None)
                if frozen_clock is None:
                    result = invoke()
                else:
                    with patch.object(self.instrumented.datetime, 'datetime', clock_class(frozen_clock)):
                        result = invoke()
                if inject_failure_after_return:
                    raise RuntimeError('INJECTED_POST_RETURN_PRECOMMIT_FAILURE')
                captured = session.finalize(result)
                self._append_fsync(captured.commit)
                for selected_id in captured.upstream_returned:
                    self._expected_restored_times[selected_id]=target['scoring_at']
                return captured
            except BaseException:
                # Even a successful preimage fsync followed by a crash leaves
                # an unresolved historical read. Do not let this instance append
                # more read events to an unverifiable history.
                self._tainted = True
                raise
            finally:
                self._session = None
        finally:
            self._lock.release()
