"""Standard-library tests; run with `python -m unittest discover -s tests -v`."""
import copy
import datetime as dt
import hashlib
import json
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from audited_retrieval import (
    Signer, iso, run_one, setup_core, independently_verify, crossing_frontier,
    CapturedRead, CaptureSession, load_instrumented_upstream, score_commitment,
)

CLOCK=dt.datetime(2026,10,10,12)

class AuditTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.D,cls.Store,cls.environment=setup_core()
        cls.signer=Signer()

    def target(self,case):
        return {'history_id':'h'+case,'cut_id':'c1','read_id':'r-'+case,
                'scoring_at':iso(CLOCK),'query_sha256':hashlib.sha256(b'query').hexdigest(),
                'k':2,'phase':'read','state_version':'s1'}

    def capture(self,case,ids,relevance):
        return run_one(None,self.D,self.Store,self.signer,scores=relevance,
                       enumeration=ids,k=2,scope=self.target(case),now=CLOCK)

    def test_boundary_tie_controls_membership(self):
        r={'c':.9,'a':.5,'b':.5,'d':.1}
        one,_=self.capture('a',['c','d','a','b'],r)
        two,_=self.capture('b',['c','d','b','a'],r)
        self.assertNotEqual(set(one.upstream_returned),set(two.upstream_returned))
        self.assertTrue(one.prepare['payload']['boundary_crossing'])
        self.assertEqual(independently_verify(self.target('a'),one.trusted_scores_ephemeral,
                         one.upstream_returned,one.prepare,one.commit,self.signer.public_b64()),'ACCEPT')
        self.assertEqual(independently_verify(self.target('a'),one.trusted_scores_ephemeral,
                         two.upstream_returned,one.prepare,one.commit,self.signer.public_b64()),'REJECT')

    def test_no_tie_does_not_save_candidate_order(self):
        r={f'x{i:03d}': .9-.001*i for i in range(64)}
        c,_=self.capture('strict',list(r),r)
        self.assertFalse(c.prepare['payload']['boundary_crossing'])
        self.assertNotIn('boundary_order',c.prepare['payload'])
        self.assertNotIn('complete_candidate_order',c.prepare['payload'])

    def test_mass_tie_uses_bounded_prefix(self):
        r={f'x{i:03d}':.5 for i in range(64)}
        c,_=self.capture('mass',list(r),r)
        self.assertEqual(c.prepare['payload']['policy'],'attested-prefix')
        self.assertNotIn('boundary_order',c.prepare['payload'])
        self.assertNotIn('complete_candidate_order',c.prepare['payload'])
        self.assertEqual(independently_verify(self.target('mass'),c.trusted_scores_ephemeral,
                         c.upstream_returned,c.prepare,c.commit,self.signer.public_b64()),'ACCEPT')

    def test_wrong_signed_prefix_fail_closed(self):
        r={f'x{i:03d}':.5 for i in range(64)}
        c,_=self.capture('wrong',list(r),r)
        p=copy.deepcopy(c.prepare['payload']);p['selected_order']=['not-a-candidate','x002']
        fake=self.signer.sign(p)
        cp=copy.deepcopy(c.commit['payload'])
        from audited_retrieval import digest
        cp['prepare_sha256']=digest(p);cp['actual_order']=p['selected_order']
        self.assertEqual(independently_verify(self.target('wrong'),c.trusted_scores_ephemeral,
                         c.upstream_returned,fake,self.signer.sign(cp),self.signer.public_b64()),'UNVERIFIABLE')

    def test_score_reference_mismatch_abstains(self):
        r={'a':.4,'b':.4,'c':.9,'d':.1}
        c,_=self.capture('score',['a','b','c','d'],r)
        scores=copy.deepcopy(c.trusted_scores_ephemeral);scores['a']+=.00000001
        self.assertEqual(independently_verify(self.target('score'),scores,c.upstream_returned,
                         c.prepare,c.commit,self.signer.public_b64()),'UNVERIFIABLE')

    def test_wrong_signing_key_abstains(self):
        r={'a':.4,'b':.4,'c':.9,'d':.1}
        c,_=self.capture('key',['a','b','c','d'],r)
        self.assertEqual(independently_verify(self.target('key'),c.trusted_scores_ephemeral,
                         c.upstream_returned,c.prepare,c.commit,Signer().public_b64()),'UNVERIFIABLE')

    def test_missing_commit_abstains(self):
        r={'a':.4,'b':.4,'c':.9,'d':.1}
        c,_=self.capture('commit',['a','b','c','d'],r)
        self.assertEqual(independently_verify(self.target('commit'),c.trusted_scores_ephemeral,
                         c.upstream_returned,c.prepare,{},self.signer.public_b64()),'UNVERIFIABLE')

if __name__=='__main__':unittest.main()
