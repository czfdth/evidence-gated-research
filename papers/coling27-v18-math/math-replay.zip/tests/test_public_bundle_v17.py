import hashlib
from pathlib import Path
import tempfile
import unittest
import zipfile
from scripts.verify_public_bundle_v17 import verify_bundle,unpack_safe

class BundleDefenseTests(unittest.TestCase):
    def test_hash_mismatch_refused(self):
        with tempfile.TemporaryDirectory() as td:
            r=Path(td);z=r/'evidence.zip';side=r/'evidence.zip.sha256'
            with zipfile.ZipFile(z,'w') as f:f.writestr('results/file','x')
            side.write_text('f'*64+'  evidence.zip\n')
            with self.assertRaises(AssertionError):verify_bundle(z,side)
    def test_path_traversal_refused(self):
        with tempfile.TemporaryDirectory() as td:
            r=Path(td);z=r/'bad.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('results/../../bad.txt','oops')
            with self.assertRaisesRegex(ValueError,'unsafe archive path'):unpack_safe(z,r/'dest')
    def test_wrong_root_refused(self):
        with tempfile.TemporaryDirectory() as td:
            r=Path(td);z=r/'bad.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('private/secrets.txt','oops')
            with self.assertRaises(ValueError):unpack_safe(z,r/'dest')
if __name__=='__main__':unittest.main()
