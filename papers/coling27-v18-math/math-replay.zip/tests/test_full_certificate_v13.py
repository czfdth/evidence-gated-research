"""Full archive: independent arithmetic verification and adversarial corruption."""
import copy
import gzip
import hashlib
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from experiments.verify_all_certificates import audit

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'results/v13-full-certificate-audit'
REFERENCE=ROOT/'results/main-v11'

class FullCertificateAuditTest(unittest.TestCase):
    def test_entire_archive(self):
        self.assertEqual(audit(SOURCE,REFERENCE)['checked'],4401)

    def _tampered_copy(self, change):
        tmp=tempfile.TemporaryDirectory()
        folder=Path(tmp.name)
        shutil.copy2(SOURCE/'full-certificate-manifest.json',folder)
        compressed=SOURCE/'all-4401-negative-certificates.jsonl.gz'
        lines=gzip.decompress(compressed.read_bytes()).splitlines()
        row=json.loads(lines[0]); change(row)
        lines[0]=json.dumps(row,sort_keys=True,separators=(',',':')).encode()
        with (folder/'all-4401-negative-certificates.jsonl.gz').open('wb') as fd:
            with gzip.GzipFile(fileobj=fd, mode='wb',mtime=0,filename='') as out:
                out.write(b'\n'.join(lines)+b'\n')
        manifest=json.loads((folder/'full-certificate-manifest.json').read_text())
        manifest['full_certificate_sha256']=hashlib.sha256((folder/'all-4401-negative-certificates.jsonl.gz').read_bytes()).hexdigest()
        (folder/'full-certificate-manifest.json').write_text(json.dumps(manifest))
        return tmp,folder

    def test_corrupted_negative_bound_rejected_even_with_rehashed_archive(self):
        tmp,folder=self._tampered_copy(lambda row:row.update(upper_bound=-99))
        try:
            with self.assertRaises(AssertionError):audit(folder,REFERENCE)
        finally:tmp.cleanup()

    def test_corrupted_normalization_rejected_even_with_rehashed_archive(self):
        tmp,folder=self._tampered_copy(lambda row:row['weights'].__setitem__(0,10.))
        try:
            with self.assertRaises(AssertionError):audit(folder,REFERENCE)
        finally:tmp.cleanup()

if __name__=='__main__':unittest.main()
