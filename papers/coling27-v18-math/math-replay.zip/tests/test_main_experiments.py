import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
import main_experiments as m
import numpy as np

class MainExperiments(unittest.TestCase):
    def test_two_way_joint_reject(self):
        b=np.array([-.7,.3,.2]);a=np.array([[1.],[-1.],[0.]])
        self.assertEqual(m.independent_verdict(*m.affine_bounds(b,a,{})[:2]),'UNVERIFIABLE')
        self.assertEqual(m.verify_claim(b,a,np.array([.6]),{})[2],'REJECT')
    def test_three_way_joint_reject(self):
        b=np.array([-.7,-.7,1.]);a=np.array([[1.,0.],[0.,1.],[-1.,-1.]])
        oracle,base,joint,cert=m.verify_claim(b,a,np.array([.5,.5]),{})
        self.assertEqual((oracle,base,joint),('REJECT','UNVERIFIABLE','REJECT'))
        self.assertEqual(cert['support'],3)
        self.assertFalse(m.verify_negative(b,a,np.array([1.,0.,0.])))
    def test_always_positive(self):
        b=np.array([.2,.3]);a=np.array([[.2,0.],[0.,.1]])
        self.assertEqual(m.verify_claim(b,a,np.array([.4,.3]),{})[:3],('ACCEPT','ACCEPT','ACCEPT'))
    def test_point_truth_never_rejected(self):
        rng=np.random.default_rng(1)
        for _ in range(60):
            a=rng.uniform(-1,1,(4,3));b=rng.uniform(-1,1,4);z=rng.random(3)
            for known in ({},{0:float(z[0])},{0:float(z[0]),1:float(z[1]),2:float(z[2])}):
                m.verify_claim(b,a,z,known)
    def test_capture_rejects_bad_certificate(self):
        self.assertFalse(m.verify_negative(np.array([-.1,.2]),np.array([[0.],[0.]]),np.array([.5,.4])))

if __name__=='__main__':unittest.main()
