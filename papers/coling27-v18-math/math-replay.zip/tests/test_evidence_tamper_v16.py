"""v16 narrow tests of mutation-vs-neutral behavior and frozen matrix."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from experiments.evidence_tamper_campaign_v16 import mutate
from experiments.verify_agent_run import check
from experiments.verify_evidence_tamper_v16 import verify
import shutil

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'results/agent-shim-v15'
FROZEN=ROOT/'results/tamper-study-v16'

class TamperCampaignValidation(unittest.TestCase):
 def test_logged_90_trials(self):
  self.assertEqual(verify(FROZEN,SRC)['rows_verified'],90)
 def test_fresh_tamper_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   dest=Path(td)/'data';shutil.copytree(SRC,dest)
   mutate(dest,'T-000','preimage_replay_between_reads')
   with self.assertRaises(Exception):check(dest,'shim')
 def test_fresh_neutral_reformat_accepted(self):
  with tempfile.TemporaryDirectory() as td:
   dest=Path(td)/'data';shutil.copytree(SRC,dest)
   mutate(dest,'T-001','episode_summary_reformat_control')
   self.assertEqual(check(dest,'shim')['verdict'],'PASS')
 def test_forced_log_false_positive_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)
   shutil.copy2(FROZEN/'summary.json',p/'summary.json')
   src=FROZEN/'per_mutation.jsonl'
   rows=[json.loads(x) for x in src.read_text().splitlines()]
   rows[0]['actual']='ACCEPT'
   raw=('\n'.join(json.dumps(x,sort_keys=True) for x in rows)+'\n').encode()
   (p/'per_mutation.jsonl').write_bytes(raw)
   s=json.loads((p/'summary.json').read_text())
   import hashlib
   s['per_mutation_sha256']=hashlib.sha256(raw).hexdigest()
   (p/'summary.json').write_text(json.dumps(s))
   with self.assertRaises(AssertionError):verify(p,SRC)

if __name__=='__main__':unittest.main()
