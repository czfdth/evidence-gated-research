"""Offline deterministic agent-style integration regression tests.

These run SHA-pinned retriever source under shims, NOT real installed core.
"""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from experiments.agent_workload import run
from experiments.verify_agent_run import check

class AgentWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        run('shim',self.root,episodes=4)
    def tearDown(self):self.tmp.cleanup()
    def test_offline_evidence_passes(self):
        self.assertEqual(check(self.root,'shim')['verdict'],'PASS')
    def test_fails_on_wrong_backend_claim(self):
        with self.assertRaises(ValueError):check(self.root,'real')
    def test_signed_prepare_tamper_fails(self):
        path=self.root/'episodes'/'T-000'/'ledger.jsonl'
        data=[json.loads(v) for v in path.read_text().splitlines()]
        data[0]['payload']['selected_order']=['T-000-fabricated']
        path.write_text(''.join(json.dumps(v)+'\n' for v in data))
        with self.assertRaises(ValueError):check(self.root,'shim')
    def test_tool_trace_action_tamper_fails(self):
        path=self.root/'episodes'/'T-000'/'tool-trace.json'
        data=json.loads(path.read_text())
        data[-1]['args']={'approved':True}
        path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):check(self.root,'shim')
    def test_cross_read_timestamp_tamper_fails(self):
        path=self.root/'episodes'/'T-000'/'read-2.json'
        data=json.loads(path.read_text())
        data['state_before']['T-000-d0']='2001-01-01T00:00:00'
        path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):check(self.root,'shim')
    def test_forged_untrusted_text_fails_closed(self):
        path=self.root/'episodes'/'T-000'/'tool-trace.json'
        data=json.loads(path.read_text())
        data[1]['response']['untrusted_text']=['safe note']
        path.write_text(json.dumps(data))
        with self.assertRaises(ValueError):check(self.root,'shim')

if __name__=='__main__':unittest.main()
