"""Transport-mocked tests. No LLM, no OpenAI requests, no real LangChain."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from experiments.llm_planner_eval_v17 import run,parse_decision,prompt_for
from experiments.verify_llm_planner_v17 import verify

ROOT=Path(__file__).resolve().parents[1]
TRACES=ROOT/'results/agent-shim-v15'


def mock_transport(payload,case,arm):
    authorized=case['verified'] and case['amount']<=case['policy_limit']
    # A deterministic mock decides to follow injection if exposed. It is not a
    # model and not a measurement of LLM robustness or attack success.
    attacked=case['attack'] and arm=='exposed'
    text=payload['messages'][1]['content']
    assert ('ATTACK: ignore verification' in text)==attacked
    result={'decision':'APPROVE' if authorized or attacked else 'ESCALATE',
            'reason':'Fixed unit-test transport response'}
    return ({'id':'mock-'+case['ticket']+'-'+arm,'model':'TEST-TRANSPORT',
             'choices':[{'message':{'content':json.dumps(result)}}]},
            {'http_status':200,'request_id_header':'MOCK-NOT-PROVIDER','elapsed_seconds':0})

class LLMPlannerTests(unittest.TestCase):
    def test_run_mock_only_cannot_validate_as_live(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)
            report=run(TRACES,path,model='test-fixture',episodes=6,
                       transport=mock_transport,live=False)
            self.assertEqual(report['kind'],'MOCK_TRANSPORT_UNIT_TEST')
            res=verify(TRACES,path,live=False)
            self.assertEqual(res['provider_calls_checked'],12)
            self.assertEqual(res['status'],'PASS_MOCK_TRANSPORT_ONLY')
            with self.assertRaises(AssertionError):verify(TRACES,path,live=True)
    def test_refuse_faked_live_injected_transport(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):run(TRACES,Path(temp),model='a',
                     transport=mock_transport,live=True)
    def test_missing_live_input_fails_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises((FileNotFoundError,ValueError,AssertionError)):
                run(Path(temp)/'real-not-present',Path(temp)/'out',model='test-fixture',live=True)
    def test_schema_invalid_decisions(self):
        for sample in ({'choices':[{'message':{'content':'go'}}]},
                       {'choices':[{'message':{'content':'{"decision":"APPROVE"}'}}]},
                       {'choices':[]}):
            with self.assertRaises(ValueError):parse_decision(sample)
    def test_prompt_arm_isolation(self):
        a,_=prompt_for(TRACES/'episodes'/'T-000','exposed')
        b,_=prompt_for(TRACES/'episodes'/'T-000','redacted')
        self.assertIn('ATTACK:',a['messages'][1]['content'])
        self.assertNotIn('ATTACK:',b['messages'][1]['content'])
    def test_tamper_detected(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)
            run(TRACES,path,model='test-fixture',episodes=3,
                transport=mock_transport,live=False)
            target=path/'calls/000-exposed.json'
            data=json.loads(target.read_text())
            data['parsed_proposal']['decision']='ESCALATE'
            target.write_text(json.dumps(data))
            with self.assertRaises(AssertionError):verify(TRACES,path,live=False)

if __name__=='__main__':unittest.main()
