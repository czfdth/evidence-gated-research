"""Offline transcript adversarial tests: never counted as real LangChain runs."""
import copy
import datetime as dt
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from audited_retrieval import (Signer, SELECTOR, UPSTREAM_SHA256,
                               canonical, digest, iso, score_commitment)
from experiments.verify_real_run import check

T0=dt.datetime(2026,10,10,12)


def put(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')


def make_synthetic(folder):
    root=Path(folder); root.mkdir(exist_ok=True,parents=True)
    signer=Signer(); key=signer.public_b64()
    states={f'd{i}':iso(T0-dt.timedelta(hours=2)) for i in range(4)}
    put(root/'initial-state.json',states)
    scores={'d0':2.,'d1':2.,'d2':1.,'d3':1.}
    ledger=[]
    for i in (1,2):
        now=T0+dt.timedelta(minutes=10*(i-1))
        target={'history_id':'installed-core-h1','read_id':f'run-{i}',
                'cut_id':f'cut-{i}','state_version':f'state-{i}',
                'phase':'read','k':2,'scoring_at':iso(now),
                'query_sha256':hashlib.sha256(b'query').hexdigest()}
        prep={'v':1,'kind':'prepare','scope':target,'selector':SELECTOR,
              'upstream_sha256':UPSTREAM_SHA256,'candidate_count':4,
              'score_commitment':score_commitment(scores),
              'selected_order':['d0','d1'],'boundary_crossing':False,
              'policy':'conditional-boundary'}
        pre={'v':1,'kind':'preimage','scope':target,'prepare_sha256':digest(prep),
             'selected_old_access':[{'id':d,'last_accessed_at':states[d]}
                                    for d in ('d0','d1')]}
        commit={'v':1,'kind':'commit','scope':target,'prepare_sha256':digest(prep),
                'actual_order':['d0','d1']}
        events=[signer.sign(x) for x in (prep,pre,commit)]
        (root/f'read-{i}-ledger.jsonl').write_bytes(b''.join(canonical(e)+b'\n' for e in events))
        (root/f'read-{i}-public-key.b64').write_text(key+'\n')
        for label,obj in [('target',target),('trusted-scores',scores),('observed-return',['d0','d1'])]:
            put(root/f'read-{i}-{label}.json',obj)
        ledger+=events
        for d in ('d0','d1'):states[d]=iso(now)
    (root/'two-read-ledger.jsonl').write_bytes(b''.join(canonical(e)+b'\n' for e in ledger))
    put(root/'validation-report.json',{
         'mode':'SYNTHETIC_EVIDENCE_TEST','framework_path':'synthetic',
         'continuous_signed_read_count':2,'ledger_event_count':6,
         'verified_reads':[{'selected':['d0','d1'],'verdict':'ACCEPT','preimage_count':2}]*2})
    return signer,ledger


class TranscriptAudit(unittest.TestCase):
    def test_two_reads_consistent_but_not_real_installed(self):
        with tempfile.TemporaryDirectory() as td:
            make_synthetic(td)
            self.assertEqual(check(Path(td),require_real=False)['signed_events_verified'],6)
            with self.assertRaises(AssertionError):check(Path(td),require_real=True)
    def test_validly_signed_forged_preimage_detected(self):
        with tempfile.TemporaryDirectory() as td:
            signer,events=make_synthetic(td)
            forged=copy.deepcopy(events[4]['payload'])
            forged['selected_old_access'][0]['last_accessed_at']=iso(T0-dt.timedelta(days=7))
            events[4]=signer.sign(forged)
            root=Path(td)
            (root/'two-read-ledger.jsonl').write_bytes(b''.join(canonical(e)+b'\n' for e in events))
            (root/'read-2-ledger.jsonl').write_bytes(b''.join(canonical(e)+b'\n' for e in events[3:6]))
            with self.assertRaisesRegex(AssertionError,'timestamp continuity'):
                check(root,require_real=False)
    def test_split_ledger_mismatch_detected(self):
        with tempfile.TemporaryDirectory() as td:
            make_synthetic(td)
            f=Path(td)/'read-1-ledger.jsonl'
            lines=f.read_bytes().splitlines()
            f.write_bytes(b'\n'.join(reversed(lines))+b'\n')
            with self.assertRaisesRegex(AssertionError,'global ledger differ'):
                check(Path(td),require_real=False)
    def test_missing_commit_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            make_synthetic(td)
            root=Path(td);f=root/'two-read-ledger.jsonl';f.write_bytes(b'\n'.join(f.read_bytes().splitlines()[:-1])+b'\n')
            with self.assertRaises(AssertionError):check(root,require_real=False)

if __name__=='__main__':unittest.main()
