"""v18: deliberate test transport only; never runs a real language model."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from experiments.llm_planner_eval_v17 import run,arm_schedule
from experiments.verify_llm_planner_v17 import verify
from experiments.paired_analysis_v18 import analyze,paired_stats
from experiments.run_mock_v18 import mock

ROOT=Path(__file__).resolve().parents[1]
TRACES=ROOT/'results/agent-shim-v15'

class V18AnalysisTests(unittest.TestCase):
    def test_counterbalance_and_paired_statistics(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'mock'
            run(TRACES,out,model='MOCK-NOT-LLM',episodes=6,transport=mock,live=False)
            self.assertEqual(verify(TRACES,out,live=False)['provider_calls_checked'],12)
            result=analyze(TRACES,out,live=False)
            self.assertEqual(result['episodes'],6)
            self.assertEqual(result['mode'],'MOCK_TRANSPORT_UNIT_TEST')
            self.assertEqual(arm_schedule(0),('exposed','redacted'))
            self.assertEqual(arm_schedule(1),('redacted','exposed'))
            self.assertEqual(result['metrics']['all']['unsafe']['n_pairs'],6)
    def test_sequence_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'mock'
            run(TRACES,out,model='MOCK-NOT-LLM',episodes=2,transport=mock,live=False)
            p=out/'calls'/'001-redacted.json'
            j=json.loads(p.read_text());j['provider_request_sequence']=1;p.write_text(json.dumps(j))
            with self.assertRaises(AssertionError):verify(TRACES,out,live=False)
    def test_invalid_json_captured_not_mislabeled_safe(self):
        def invalid_transport(payload,case,arm):
            response,meta=mock(payload,case,arm)
            if arm=='redacted':response['choices'][0]['message']['content']='not JSON'
            return response,meta
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'mock'
            m=run(TRACES,out,model='MOCK-NOT-LLM',episodes=2,transport=invalid_transport,live=False)
            self.assertEqual(m['invalid_outputs'],2)
            self.assertEqual(m['valid_outputs'],2)
            self.assertEqual(verify(TRACES,out,live=False)['total_invalid_outputs'],2)
            r=analyze(TRACES,out,live=False)
            self.assertEqual(r['metrics']['all']['invalid']['redacted_rate'],1.0)
            self.assertEqual(r['metrics']['all']['correct']['redacted_rate'],0.0)
    def test_mcnemar_exact(self):
        rows=[]
        for i in range(5):rows.append({'exposed':{'unsafe':True},'redacted':{'unsafe':False}})
        v=paired_stats(rows,'unsafe')
        self.assertEqual(v['mcnemar_exact_two_sided_p'],0.0625)
        self.assertEqual(v['discordant_exposed_only'],5)
        self.assertEqual(v['paired_risk_difference_exposed_minus_redacted'],1)
    def test_live_spoofed_mode_refused(self):
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'mock'
            run(TRACES,out,model='MOCK-NOT-LLM',episodes=1,transport=mock,live=False)
            m=out/'run-manifest.json'
            o=json.loads(m.read_text());o['kind']='LIVE_PROVIDER';m.write_text(json.dumps(o))
            with self.assertRaises(AssertionError):verify(TRACES,out,live=True)

if __name__=='__main__':unittest.main()
