"""Multi-read and fail-closed tests; both source-shim and installed-core modes."""
import datetime as dt
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from audited_retrieval import Signer, iso, setup_core, independently_verify, InvalidEvidence, digest
from runtime_lifecycle import AuditedLifecycle

CLOCK=dt.datetime(2026,10,10,12)

class LifecycleTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.Doc, cls.StoreBase, cls.env=setup_core()

    def make_runtime(self, path, signer=None):
        class Store(self.StoreBase):
            def similarity_search_with_relevance_scores(self, query, **kwargs):
                return [(d, .8 if d.metadata['item_id']!='d3' else .1) for d in self.docs]
            def similarity_search(self, query, k=4, **kwargs):
                return [d for d,_ in self.similarity_search_with_relevance_scores(query)][:k]
            @classmethod
            def from_texts(cls, texts, embedding, metadatas=None, **kwargs):
                raise NotImplementedError
            def add_texts(self, texts, metadatas=None, **kwargs):
                raise NotImplementedError
        store=Store()
        docs=[self.Doc(page_content=f'memory {i}',metadata={'item_id':f'd{i}',
              'buffer_idx':i,'last_accessed_at':CLOCK-dt.timedelta(hours=2),
              'importance':0.0}) for i in range(4)]
        store.docs=docs
        signer=signer or Signer()
        runtime=AuditedLifecycle(vectorstore=store,memory_stream=docs,k=2,
                  signer=signer,ledger_path=path,search_kwargs={'k':4},
                  prefer_real=(self.env['mode']=='REAL_INSTALLED_CORE'))
        return runtime,signer

    def target(self, idx, clock):
        return dict(history_id='h',cut_id='c0',read_id=f'r{idx}',phase='read',
                    state_version=f'v{idx}',query_sha256=hashlib.sha256(b'query').hexdigest(),
                    scoring_at=iso(clock), k=2)

    def test_two_consecutive_signed_reads_and_timestamp_preimages(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            runtime,signer=self.make_runtime(path)
            c1=runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            old={x['id']:x['last_accessed_at'] for x in runtime._session.preimages['payload']['selected_old_access']} if runtime._session else None
            self.assertIsNone(old)  # Session is never left active after return.
            second_clock=CLOCK+dt.timedelta(minutes=10)
            c2=runtime.read('query',self.target(2,second_clock),frozen_clock=second_clock)
            events=[json.loads(x) for x in path.read_text().splitlines()]
            self.assertEqual([e['payload']['kind'] for e in events],
                             ['prepare','preimage','commit']*2)
            first_old=events[1]['payload']['selected_old_access']
            second_old=events[4]['payload']['selected_old_access']
            self.assertTrue(all(x['last_accessed_at']==iso(CLOCK-dt.timedelta(hours=2)) for x in first_old))
            self.assertEqual(second_old,[{'id':x,'last_accessed_at':iso(CLOCK)} for x in c2.upstream_returned])
            self.assertEqual(events[1]['payload']['prepare_sha256'],digest(events[0]['payload']))
            self.assertEqual(events[4]['payload']['prepare_sha256'],digest(events[3]['payload']))
            self.assertNotEqual(events[1]['payload']['prepare_sha256'],events[4]['payload']['prepare_sha256'])
            self.assertEqual(independently_verify(self.target(1,CLOCK),c1.trusted_scores_ephemeral,
                c1.upstream_returned,c1.prepare,c1.commit,signer.public_b64()),'ACCEPT')
            self.assertEqual(independently_verify(self.target(2,second_clock),c2.trusted_scores_ephemeral,
                c2.upstream_returned,c2.prepare,c2.commit,signer.public_b64()),'ACCEPT')
            with self.assertRaises(InvalidEvidence):
                runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            restarted,_=self.make_runtime(path,signer)
            with self.assertRaises(InvalidEvidence):
                restarted.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)

    def test_restart_refuses_stale_memory_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            runtime,signer=self.make_runtime(path)
            runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            restarted,_=self.make_runtime(path,signer)
            later=CLOCK+dt.timedelta(minutes=10)
            with self.assertRaisesRegex(InvalidEvidence,'restored memory timestamps'):
                restarted.read('query',self.target(2,later),frozen_clock=later)

    def test_prepare_fsync_error_prevents_timestamp_mutation(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime,_=self.make_runtime(Path(tmp)/'events.jsonl')
            before=[d.metadata['last_accessed_at'] for d in runtime.retriever.memory_stream]
            def fail(*args):
                raise OSError('INJECTED_FSYNC_ERROR')
            runtime._persist_prepare=fail
            with self.assertRaisesRegex(OSError,'INJECTED_FSYNC_ERROR'):
                runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            after=[d.metadata['last_accessed_at'] for d in runtime.retriever.memory_stream]
            self.assertEqual(before,after)

    def test_post_return_crash_does_not_create_commit(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            runtime,signer=self.make_runtime(path)
            with self.assertRaisesRegex(RuntimeError,'INJECTED_POST_RETURN_PRECOMMIT_FAILURE'):
                runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK,
                    inject_failure_after_return=True)
            events=[json.loads(x) for x in path.read_text().splitlines()]
            self.assertEqual([e['payload']['kind'] for e in events],['prepare','preimage'])
            self.assertTrue(any(d.metadata['last_accessed_at']==CLOCK for d in runtime.retriever.memory_stream))
            self.assertEqual(independently_verify(self.target(1,CLOCK),{f'd{i}':1.0 for i in range(4)},
                            ['d0','d1'],events[0],{},signer.public_b64()),'UNVERIFIABLE')
            with self.assertRaisesRegex(InvalidEvidence,'tainted'):
                runtime.read('query',self.target(2,CLOCK+dt.timedelta(minutes=10)),
                             frozen_clock=CLOCK+dt.timedelta(minutes=10))
            with self.assertRaisesRegex(InvalidEvidence,'incomplete persisted'):
                self.make_runtime(path,signer)

    def test_persisted_ledger_rejects_wrong_signing_key(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            runtime,signer=self.make_runtime(path)
            runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            with self.assertRaisesRegex(InvalidEvidence,'signature invalid'):
                self.make_runtime(path,Signer())

    def test_complete_ledger_rejects_forged_signed_commit(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'events.jsonl'
            runtime,signer=self.make_runtime(path)
            runtime.read('query',self.target(1,CLOCK),frozen_clock=CLOCK)
            events=[json.loads(x) for x in path.read_text().splitlines()]
            altered=events[-1]['payload'].copy()
            altered['actual_order']=list(reversed(altered['actual_order']))
            events[-1]=signer.sign(altered)
            path.write_bytes(b''.join(__import__('audited_retrieval').canonical(x)+b'\n' for x in events))
            with self.assertRaisesRegex(InvalidEvidence,'result mismatch'):
                self.make_runtime(path,signer)

if __name__=='__main__':unittest.main()
