"""Adversarial checks of offline public ZIP parser and strict preflight status."""
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from scripts.verify_public_bundle_v17 import unpack_safe
from scripts.preflight_v18 import preflight

class ReleaseV18Tests(unittest.TestCase):
    def test_duplicate_entry_refused(self):
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'evil.zip'
            with ZipFile(src,'w') as z:
                z.writestr('results/installed-core/a','first')
                z.writestr('results/installed-core/a','second')
            with self.assertRaisesRegex(ValueError,'duplicate'):unpack_safe(src,Path(td)/'unpack')
    def test_oversized_uncompressed_archive_refused(self):
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'huge.zip'
            with ZipFile(src,'w') as z:
                z.writestr('results/installed-core/a',b'0'*100_000_000)
                z.writestr('results/installed-core/b',b'0'*100_000_000)
                z.writestr('results/installed-core/c',b'0'*50_000_001)
            with self.assertRaisesRegex(ValueError,'oversized total'):unpack_safe(src,Path(td)/'unpack')
    def test_no_real_installed_framework_preflight_cannot_pass(self):
        with self.assertRaises(RuntimeError):preflight(require_live=False,check_dns=False)
if __name__=='__main__':unittest.main()
