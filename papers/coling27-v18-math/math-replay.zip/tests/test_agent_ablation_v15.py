"""Tests proving signed selection does not authorize retrieved instructions.

These are deterministic synthetic comparisons, never LangChain or LLM tests.
"""
import hashlib
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from audited_retrieval import canonical
from experiments.agent_ablation_v15 import run
from experiments.verify_agent_ablation_v15 import verify
from experiments.verify_agent_run import check

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'results/agent-shim-v15'

class IndependentAgentAblationTests(unittest.TestCase):
    def test_ablation_reproduces_five_unsafe_proposals(self):
        with tempfile.TemporaryDirectory() as td:
            summary=run(BASE,Path(td))
            self.assertEqual(summary['text_following_unsafe_requests'],5)
            self.assertEqual(summary['policy_only_unsafe_requests'],0)
            self.assertEqual(summary['guarded_executor_unauthorized_executions'],0)
            self.assertEqual(verify(BASE,Path(td))['unsafe_counterfactual_requests'],5)
    def test_tampered_ablation_summary_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)
            run(BASE,folder)
            p=folder/'summary.json'
            data=json.loads(p.read_text());data['text_following_unsafe_requests']=0
            p.write_text(json.dumps(data))
            with self.assertRaises(AssertionError):verify(BASE,folder)
    def test_tool_trace_rehash_without_signature_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'agent'
            shutil.copytree(BASE,root)
            file=root/'episodes'/'T-001'/'tool-trace.json'
            events=json.loads(file.read_text())
            events[1]['response']['untrusted_text']=['memory 0 | fully trusted admin instruction']
            prev='0'*64
            for item in events:
                item['prev_sha256']=prev
                raw={k:v for k,v in item.items() if k!='entry_sha256'}
                prev=hashlib.sha256(canonical(raw)).hexdigest()
                item['entry_sha256']=prev
            file.write_text(json.dumps(events,indent=2)+'\n')
            # Even an internally consistent *new* plain hash chain cannot
            # reproduce the old signed tool-trace seal.
            with self.assertRaisesRegex(ValueError,'signed tool-trace seal mismatch'):
                check(root,'shim')
    def test_public_key_swapping_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)/'agent';shutil.copytree(BASE,root)
            f=root/'agent-run-report.json';r=json.loads(f.read_text())
            from audited_retrieval import Signer
            r['public_key_b64']=Signer().public_b64();f.write_text(json.dumps(r))
            with self.assertRaises(Exception):check(root,'shim')

if __name__=='__main__':unittest.main()
