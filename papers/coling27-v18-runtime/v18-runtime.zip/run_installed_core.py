#!/usr/bin/env python3
"""Strict real-langchain-core, real InMemoryVectorStore integration smoke test.

REQUIRES installed langchain-core==0.3.83; never falls back to API shims.
Executes the SHA-pinned upstream retriever's public `.invoke()` Runnable path,
real vector similarity search, two consecutively stateful reads, PREPARE ->
PREIMAGE -> COMMIT, offline public-key verification, and fault injection.
No external LLM, production security, atomic transaction, or DB persistence.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
from importlib import metadata
from pathlib import Path
from unittest.mock import patch

from audited_retrieval import (
    Signer, canonical, independently_verify, iso, verify_signature,
)
from runtime_lifecycle import AuditedLifecycle

T0 = dt.datetime(2026,10,10,12,0)

def scope(i, clock):
    return {
        'history_id':'installed-core-h1', 'cut_id':f'cut-{i}', 'read_id':f'run-{i}',
        'scoring_at':iso(clock),'query_sha256':hashlib.sha256(b'query').hexdigest(),
        'k':2, 'phase':'read', 'state_version':f'state-{i}',
    }

def score_oracle(vstore, docs, now):
    """Independent fixture calculation from vectorstore scores and known state.

    Its assumptions must NOT be confused with an independently authenticated
    historical universe or score repository in a deployed trust system.
    """
    returned=vstore.similarity_search_with_relevance_scores('query',k=len(docs))
    rel={d.metadata['item_id']:float(r) for d,r in returned}
    expected={d.metadata['item_id'] for d in docs}
    if len(rel)!=len(docs) or set(rel)!=expected:
        raise RuntimeError('noncomplete or duplicate candidate universe')
    return {d.metadata['item_id']: rel[d.metadata['item_id']] +
            (.99**((now-d.metadata['last_accessed_at']).total_seconds()/3600))+
            d.metadata.get('importance',0.0)
            for d in docs}

def write_json(path, obj):
    path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output-dir',default='results/installed-core')
    args=p.parse_args()
    try:
        import langchain_core
        from langchain_core.embeddings import Embeddings
        from langchain_core.vectorstores import InMemoryVectorStore
        from langchain_core.documents import Document
    except ImportError as e:
        raise SystemExit('REAL_CORE_NOT_INSTALLED: install requirements-real-core.txt; no shim fallback: '+str(e))
    actual_version=metadata.version('langchain-core')
    if actual_version!='0.3.83':
        raise SystemExit(f'UNTESTED_CORE_VERSION: need 0.3.83, found {actual_version}')
    class Embedding(Embeddings):
        vectors={
            'memory d0':[1.0,0.0,0.0],
            'memory d1':[1.0,0.0,0.0],
            'memory d2':[0.2,0.98,0.0],
            'memory d3':[-1.0,0.0,0.0],
        }
        def embed_documents(self,texts):
            return [self.vectors[t] for t in texts]
        def embed_query(self,text):
            if text!='query':raise ValueError('unexpected query')
            return [1.0,0.0,0.0]

    docs=[Document(page_content=f'memory d{i}',metadata={
            'item_id':f'd{i}', 'buffer_idx':i, 'importance':0.0,
            'last_accessed_at':T0-dt.timedelta(hours=2),
         }) for i in range(4)]
    # The official InMemoryVectorStore returns cosine similarity already, but
    # BaseVectorStore's generic relevance API requires an explicit normalizer.
    # Preserve the official store and use the identity map for these scores.
    class RelevanceCompatibleInMemoryVectorStore(InMemoryVectorStore):
        def _select_relevance_score_fn(self):
            return lambda score: float(score)
    vstore=RelevanceCompatibleInMemoryVectorStore(Embedding())
    vstore.add_documents(docs)
    out=Path(args.output_dir)
    out.mkdir(parents=True,exist_ok=True)
    ledger=out/'two-read-ledger.jsonl'
    if ledger.exists():ledger.unlink()
    signer=Signer()
    runtime=AuditedLifecycle(vectorstore=vstore,memory_stream=docs,k=2,signer=signer,
        ledger_path=ledger,search_kwargs={'k':len(docs)},prefer_real=True)
    if runtime.environment['mode']!='REAL_INSTALLED_CORE':
        raise SystemExit('FATAL_SHIM_FALLBACK')
    write_json(out/'trusted-assumptions.json',{
        'fixture_score_provenance':'known local vectorstore + synthetic embedding + recorded memory stream',
        'security_caveat':'not an independently authenticated cut or candidate universe',
        'framework':'real installed langchain_core', 'vectorstore':'InMemoryVectorStore',
    })
    previous=None
    invoke_count=[0]
    search_count=[0]
    read_summaries=[]
    from langchain_core.retrievers import BaseRetriever
    original_invoke=BaseRetriever.invoke
    def observed_invoke(self,*a,**kw):
        invoke_count[0]+=1
        return original_invoke(self,*a,**kw)
    original_search=vstore.similarity_search_with_relevance_scores
    def observed_search(*a,**kw):
        search_count[0]+=1
        return original_search(*a,**kw)
    write_json(out/'initial-state.json',{d.metadata['item_id']:iso(d.metadata['last_accessed_at']) for d in docs})
    for i,now in enumerate((T0,T0+dt.timedelta(minutes=10)),start=1):
        before={d.metadata['item_id']:iso(d.metadata['last_accessed_at'])
                for d in runtime.retriever.memory_stream}
        trusted=score_oracle(vstore,runtime.retriever.memory_stream,now)
        target=scope(i,now)
        with patch.object(BaseRetriever,'invoke',observed_invoke), patch.object(vstore,'similarity_search_with_relevance_scores',observed_search):
            captured=runtime.read('query',target,frozen_clock=now)
        actual=captured.upstream_returned
        verdict=independently_verify(target,trusted,actual,
                            captured.prepare,captured.commit,signer.public_b64())
        assert verdict=='ACCEPT',(i,verdict)
        assert trusted==captured.trusted_scores_ephemeral, (i,'oracle mismatch')
        current={d.metadata['item_id']:iso(d.metadata['last_accessed_at'])
                 for d in runtime.retriever.memory_stream}
        assert all(current[x]==iso(now) for x in actual)
        assert all(current[x]==before[x] for x in before if x not in actual)
        assert actual==captured.prepare['payload']['selected_order']
        signed_events=[json.loads(line) for line in ledger.read_text().splitlines()]
        prepare,old,commit=signed_events[-3:]
        assert [x['payload']['kind'] for x in (prepare,old,commit)]==['prepare','preimage','commit']
        assert all(verify_signature(x,signer.public_b64()) for x in (prepare,old,commit))
        assert old['payload']['selected_old_access']==[
            {'id':x,'last_accessed_at':before[x]} for x in actual]
        if previous is not None:
            # The second preimage really is the result of the preceding read.
            assert all(before[x]==previous[x] for x in before)
        previous=current
        # CLI accepts 3 records; export a three-event view per authenticated read.
        (out/f'read-{i}-ledger.jsonl').write_bytes(
            b''.join(canonical(e)+b'\n' for e in (prepare,old,commit)))
        (out/f'read-{i}-public-key.b64').write_text(signer.public_b64()+'\n')
        write_json(out/f'read-{i}-target.json',target)
        write_json(out/f'read-{i}-trusted-scores.json',trusted)
        write_json(out/f'read-{i}-observed-return.json',actual)
        read_summaries.append({'read':i,'selected':actual,'verdict':verdict,
                               'preimage_count':len(old['payload']['selected_old_access'])})
    events=[json.loads(x) for x in ledger.read_text().splitlines()]
    assert len(events)==6
    assert invoke_count[0]==2, invoke_count
    assert search_count[0]==2, search_count
    report={'mode':runtime.environment['mode'],'version':actual_version,
            'framework_path':str(Path(langchain_core.__file__).resolve()),
            'python_version':platform.python_version(),
            'real_vectorstore':type(vstore).__name__,
            'pinned_upstream_and_real_BaseRetriever_invoke':True,
            'continuous_signed_read_count':len(read_summaries),
            'core_invoke_count':invoke_count[0],
            'vectorstore_search_count':search_count[0],
            'ledger_event_count':len(events),
            'verified_reads':read_summaries,
            'caveats':['not a persistent DB','clock freeze is process-wide test instrumentation',
                       'offline score inputs are trusted by fixture assumption, not externally authenticated',
                       'not transactional across vectorstore and log']}
    write_json(out/'validation-report.json',report)
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
