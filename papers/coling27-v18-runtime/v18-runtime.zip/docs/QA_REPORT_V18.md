# COLING artifact v18 — paired hosted-model protocol and strict public release verification

**Observed on 2026-10-10, current container:** 56/56 local tests passed. v18 provides a counterbalanced AB/BA live-model protocol, fail-closed installed-framework preflight, invalid-JSON preservation, prespecified paired analysis and hardened public release verifier. **No genuine installed LangChain or OpenAI model has run successfully in this environment.** This is not a submission-ready real-system experiment.

## Evidence actually produced here

| Item | Status | Audit location |
|---|---|---|
| 56 local unit/regression tests | PASS (source-shim, synthetic and archive defense only) | `docs/v18-unit-tests.log` |
| Full new 24-pair mock-transport dataset | 48 mock responses; 5 unauthorized proposals in exposed arm, 0 in control | `results/llm-mock-v18/calls`, `run-manifest.json` |
| Independent paired mock analysis | risk difference 0.2083; exact two-sided McNemar p=0.0625; 95% descriptive paired bootstrap interval [0.0417,0.3750] | `results/llm-mock-v18/paired-analysis.json` |
| Malformed provider-format response treated as neither safe nor unsafe | PASS via unit-test transport | `tests/test_paired_v18.py` |
| All 4,401 historical synthetic negative certificates | PASS | `docs/v18-4401-certificates.json` |
| Real installed core and real API preflight | FAIL CLOSED. Local Python 3.13, no real `langchain_core`; provider key unavailable | `docs/v18-preflight-failed.json` |
| Attempted live launch | FAIL CLOSED before any paid API call: no key | `docs/v18-live-gate-attempt.log` |
| Linked public GitHub Actions run or Release | **none**; GitHub connector returned 0 accessible repositories | workflow exists, but has not executed |

## What changed from v17

1. Live model exposure/control sequence is **counterbalanced**: even case indices see exposed first, odd cases see redacted first. Same synthetic ticket and authoritative policy stay fixed within each matched pair. Both requests are preserved with sequence numbers and declared arm order.
2. If a real provider returns invalid JSON, the raw content still becomes a permanent per-call record with `parse_status=INVALID_OUTPUT`; neither the safe nor unsafe proposal counter is incremented. Such cases reduce the correctness rate and are separately counted. Provider HTTP/network failures still fail the run and mark the manifest `FAILED`.
3. `experiments/paired_analysis_v18.py` independently invokes the full transcript verifier, then computes paired risk differences, exact McNemar p and a deterministic 10,000-resample paired bootstrap interval. Stratifications: exposed/clean memory, injected memory and policy-denied cases. This **describes synthetic case results only**, not real-population causal inference.
4. `scripts/preflight_v18.py` blocks paid calls unless Python 3.11, a verified official-core wheel, installed `langchain_core==0.3.83`, the pinned upstream source, required core public APIs, the API key and provider DNS are confirmed. A passing preflight is **not** a successful API call.
5. `scripts/verify_public_bundle_v17.py` rejects duplicate and oversized aggregate ZIP entries and now recomputes the paired summary from original published per-call records. A published evidence bundle must contain a passing preflight report before internal verification can pass.
6. `.github/workflows/public-real-llm-evidence-v18.yml` adds explicit paired-analysis verification and checks the public ZIP's own independent verifier **before** release. This workflow is unexecuted.
7. The new paper appendix describes the paired design, expected analysis and honest external-validation boundary. The model shown in local analysis is **mock**, not LLM or LangChain.

## Reproduce the executed (mock-only) test

```bash
python -m unittest discover -s tests -v
python -m experiments.run_mock_v18  # use an empty/new results/llm-mock-v18 directory
python -m experiments.paired_analysis_v18 --traces results/agent-shim-v15 --dir results/llm-mock-v18 --mode mock --out results/llm-mock-v18/paired-analysis.json
python experiments/verify_all_certificates.py --dir results/v13-full-certificate-audit --reference results/main-v11
```

## Genuine hosted-run procedure still required

1. Commit all files in the complete ZIP to a GitHub repository (public if users should independently inspect the raw experiment). This has not been performed by this environment.
2. Add `OPENAI_API_KEY` as a **repository Actions secret**, not to the code or chat. The test invokes the public hosted-model API and may cost money.
3. Dispatch `COLING v18 - audited LangChain and counterbalanced live LLM` from `.github/workflows/public-real-llm-evidence-v18.yml`. It installs and verifies the official wheel; checks prerequisite status; records two real core reads plus the 24 synthetic LangChain Tool/Runnable episodes; then sends up to 48 real provider requests in counterbalanced order; runs the independent verifiers and paired analysis; uploads stdout, raw JSON and checksums even on failure. Optional release publication is explicit opt-in in a public repository.
4. Only after a real green run and source/version/manifest validation can the paper call it a **successful hosted LangChain and LLM experiment**. Publication should cite exact commit SHA, GitHub Actions run URL, release tag, SHA-256 zip digest and complete response metadata.

## Trust and methodological limitations

The tickets, tool plan, embedding vectors and refund decisions remain synthetic. The LangChain Tool sequence is fixed, while LLM chooses only the proposed decision. Provider response metadata are not provider-signed and in-process signing keys do not prove external custody. Policy truth and full candidate universe are fixture assumptions. Alternating-order exposure reduces deterministic order confounding but does not replace genuinely randomized larger workloads. The sample is 24 fixed synthetic cases; a bootstrap interval can exclude zero even when the exact small-sample McNemar p-value exceeds 0.05. Neither constitutes a real-agent population-effect estimate. The local 5-versus-0 results were **programmatically defined by a mock transport**, and must not appear as genuine model attack rates.
