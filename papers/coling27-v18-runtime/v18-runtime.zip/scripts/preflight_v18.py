#!/usr/bin/env python3
"""Strict nonsecret preflight BEFORE spending live API money or emitting run success.

Validates official installed core, pinned retriever bytes, Python, public
provider DNS and key presence. DOES NOT validate API credentials/account funds.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
import os
import platform
import socket
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SOURCE_HASH='2a55ff628c1d44ebf1faa01008579ac26ed0ae5996daec6dcde3ae4cb9233daa'
WHEEL_HASH='8c92506f8b53fc1958b1c07447f58c5783eb8833dd3cb6dc75607c80891ab1ae'

def preflight(*,require_live=True,check_dns=True):
    result={'schema':'preflight-v18','python':platform.python_version(),
            'system':platform.platform(),'official_version_expected':'0.3.83',
            'official_wheel_sha256_expected':WHEEL_HASH,
            'pinned_upstream_sha256_expected':SOURCE_HASH,
            'api_key_present':bool(os.getenv('OPENAI_API_KEY')),
            'checks':{},'status':'FAILED',
            'note':'Local self-reported environment checks; cannot attest GitHub identity, key custody, or provider truth.'}
    if sys.version_info[:2] != (3,11):
        raise RuntimeError('Real CI requires Python 3.11')
    result['checks']['python_3_11']=True
    actual=hashlib.sha256((ROOT/'src/time_weighted_retriever.py').read_bytes()).hexdigest()
    if actual!=SOURCE_HASH:raise RuntimeError('pinned upstream SHA-256 mismatch')
    result['checks']['pinned_source_hash']=True
    try:
        import langchain_core
        from langchain_core.vectorstores import InMemoryVectorStore
        from langchain_core.retrievers import BaseRetriever
        from langchain_core.tools import tool
        from langchain_core.runnables import RunnableLambda
        version=importlib.metadata.version('langchain-core')
    except (ImportError,importlib.metadata.PackageNotFoundError) as exc:
        raise RuntimeError('Real installed langchain_core required; no shim fallback') from exc
    if version!='0.3.83':raise RuntimeError('Unexpected installed langchain-core version')
    src=Path(langchain_core.__file__).resolve()
    if not any(x in src.parts for x in ('site-packages','dist-packages')):
        raise RuntimeError('Core must reside in a real installed site/dist-packages')
    if not all(callable(x) for x in (BaseRetriever.invoke,InMemoryVectorStore,tool,RunnableLambda)):
        raise RuntimeError('installed core does not provide required public APIs')
    result['core_module_path']=str(src)
    result['installed_langchain_core_version']=version
    result['checks']['real_installed_core_apis']=True
    wheel=ROOT/'wheel-check'/'langchain_core-0.3.83-py3-none-any.whl'
    if not wheel.is_file():raise RuntimeError('Official wheel bytes must be present in wheel-check')
    if hashlib.sha256(wheel.read_bytes()).hexdigest()!=WHEEL_HASH:
        raise RuntimeError('Official wheel checksum mismatch')
    result['checks']['wheel_integrity']=True
    if require_live:
        key=os.getenv('OPENAI_API_KEY','')
        if not key or len(key)<15:raise RuntimeError('OPENAI_API_KEY secret is missing')
        result['checks']['api_key_present']=True
        if check_dns:
            if not socket.getaddrinfo('api.openai.com',443,type=socket.SOCK_STREAM):
                raise RuntimeError('OpenAI DNS resolution failed')
            result['checks']['api_dns_available']=True
    result['status']='PASS_PREFLIGHT_ONLY'
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True)
    p.add_argument('--no-live',action='store_true');p.add_argument('--skip-dns',action='store_true')
    a=p.parse_args()
    try:
        status=preflight(require_live=not a.no_live,check_dns=not a.skip_dns)
    except Exception as exc:
        # Never print API keys / exception payloads; only local controlled type.
        status={'schema':'preflight-v18','status':'FAIL_CLOSED',
                'failure_class':type(exc).__name__,
                'reason_code':str(exc) if isinstance(exc,RuntimeError) else 'unexpected failure',
                'provider_calls_made':0}
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(status,indent=2)+'\n')
    print(json.dumps(status))
    if status['status']!='PASS_PREFLIGHT_ONLY':raise SystemExit(1)
if __name__=='__main__':main()
