#!/usr/bin/env bash
# Strict real-core integration and 24-episode multi-tool exercise.
# Requires installed official langchain_core==0.3.83. NO source shim fallback.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results/installed-core results/agent-real
python -m pip freeze > results/installed-core/pip-freeze.txt
python -u run_installed_core.py --output-dir results/installed-core 2>&1 | tee results/installed-core/runner-stdout.txt
python -u experiments/verify_real_run.py --dir results/installed-core 2>&1 | tee results/installed-core/verifier-stdout.txt
python -u experiments/agent_workload.py --backend real --output-dir results/agent-real 2>&1 | tee results/agent-real/runner-stdout.txt
python -u experiments/verify_agent_run.py --backend real --dir results/agent-real 2>&1 | tee results/agent-real/verifier-stdout.txt
python scripts/evidence_manifest.py --dir results/installed-core
python scripts/evidence_manifest.py --dir results/agent-real
printf 'REAL_FRAMEWORK_AND_AGENT_INTEGRATION_PASS\n'
